#pragma once

#include <algorithm>
#include <atomic>
#include <cstdint>
#include <cstring>
#include <mutex>
#include <unordered_map>
#include "../Hacks/Feature/SkinHaxSystem.h"

namespace Blueprint {

static bool CanUseBlueprint()
{
    return Config.ExtraMenu.UnlockBlueprint;
}

static std::atomic<uint32_t> pendingBlueprint{0};
static std::atomic<int>      pendingBlueprintIndex{-1};
static std::atomic<int>      pendingBlueprintDiy{-1};

static std::mutex equippedMutex;
struct EquipData { uint32_t blueprint; int diy; };
static std::unordered_map<uint32_t, EquipData> equippedBlueprints;

static bool LocalEquip(const void *info)
{
    if (info == nullptr || !CanUseBlueprint()) return false;
    const auto *data = static_cast<const unsigned char *>(info);
    uint32_t base = 0, blueprint = 0;
    memcpy(&base,      data + 0x20, sizeof(base));
    memcpy(&blueprint, data + 0x24, sizeof(blueprint));
    std::lock_guard<std::mutex> lock(equippedMutex);
    const auto found = equippedBlueprints.find(base);
    return found != equippedBlueprints.end() && blueprint == found->second.blueprint;
}

static auto FindBlueprint(uint32_t id)
{
    return std::find_if(itemData.begin(), itemData.end(), [id](const itemInfo &item) {
        return item.WeaponConf[2] == static_cast<int>(id) && item.WeaponConf[0] > 0;
    });
}

inline void ApplyPending()
{
    const uint32_t blueprintId = pendingBlueprint.load(std::memory_order_acquire);
    if (blueprintId == 0 || !CanUseBlueprint()) return;

    if (!OblivionSkinHax::gDatabaseReady.load(std::memory_order_acquire) ||
        itemData.empty())
        return;

    auto found = FindBlueprint(blueprintId);
    if (found == itemData.end()) return;

    const int diyIndex = pendingBlueprintDiy.exchange(-1, std::memory_order_acq_rel);
    pendingBlueprintIndex.exchange(-1, std::memory_order_acq_rel);
    pendingBlueprint.store(0, std::memory_order_release);

    OblivionSkinHax::BlueprintSelectSkin(*found);

    {
        std::lock_guard<std::mutex> lock(equippedMutex);
        equippedBlueprints[static_cast<uint32_t>(found->WeaponConf[0])] =
            {blueprintId, diyIndex};
    }
}

using BlueprintEquipFn = void (*)(void *, uint32_t, void *);
static BlueprintEquipFn orig_BlueprintEquip = nullptr;

using GunsmithEquipFn = void (*)(void *, void *);
static GunsmithEquipFn orig_GunsmithEquip    = nullptr;
static GunsmithEquipFn orig_SafeHouseEquip   = nullptr;

using EquipStepFn = void (*)(void *, int, void *);
static EquipStepFn orig_EquipStep = nullptr;

using SkinResFn = void (*)(void *, void *, void *);
static SkinResFn orig_SkinRes = nullptr;

using ItemClickFn = bool (*)(void *, void *, void *, int, int, void *);
static ItemClickFn orig_ItemClick = nullptr;

using IsEquippedFn = bool (*)(void *, void *, void *);
static IsEquippedFn orig_IsEquipped = nullptr;

using WeaponIdFn   = uint32_t (*)(void *, bool, void *, void *);
static WeaponIdFn  orig_WeaponId   = nullptr;

using WeaponNameFn = void *(*)(void *, bool, void *, void *);
static WeaponNameFn orig_WeaponName = nullptr;

using EquipCheckFn = bool (*)(void *, uint32_t, uint32_t, int, void *);
static EquipCheckFn orig_EquipCheck = nullptr;

static bool (*original_Unlockskin)(void *) = nullptr;
static bool hooked_Unlockskin(void *instance)
{
    if (instance != nullptr && CanUseBlueprint())
        return true;
    return original_Unlockskin != nullptr ? original_Unlockskin(instance) : false;
}

static std::atomic<void *> clickedCtrl{nullptr};
static std::atomic<int>    clickedIndex{-1};

static bool IsBlueprintEquipped(void *view, void *info, void *method)
{
    if (info != nullptr && CanUseBlueprint()) {
        const auto *data = static_cast<const unsigned char *>(info);
        uint32_t base = 0, blueprint = 0;
        memcpy(&base,      data + 0x20, sizeof(base));
        memcpy(&blueprint, data + 0x24, sizeof(blueprint));
        std::lock_guard<std::mutex> lock(equippedMutex);
        const auto equipped = equippedBlueprints.find(base);
        if (equipped != equippedBlueprints.end())
            return blueprint == equipped->second.blueprint;
    }
    return orig_IsEquipped != nullptr ? orig_IsEquipped(view, info, method) : false;
}

static uint32_t CardWeaponId(void *view, bool equipped, void *info, void *method)
{
    if (orig_WeaponId == nullptr) return 0;
    return orig_WeaponId(view, equipped && !LocalEquip(info), info, method);
}

static void *CardWeaponName(void *view, bool equipped, void *info, void *method)
{
    if (orig_WeaponName == nullptr) return nullptr;
    return orig_WeaponName(view, equipped && !LocalEquip(info), info, method);
}

static bool IsWeaponEquipped(void *view, uint32_t base, uint32_t blueprint,
                              int diy, void *method)
{
    if (CanUseBlueprint()) {
        std::lock_guard<std::mutex> lock(equippedMutex);
        auto found = equippedBlueprints.find(base);
        if (found == equippedBlueprints.end()) {
            found = std::find_if(equippedBlueprints.begin(), equippedBlueprints.end(),
                [base](const auto &entry) { return entry.second.blueprint == base; });
        }
        if (found != equippedBlueprints.end()) {
            return blueprint == found->second.blueprint &&
                   (found->second.diy < 0 || diy == found->second.diy);
        }
    }
    return orig_EquipCheck != nullptr
        ? orig_EquipCheck(view, base, blueprint, diy, method) : false;
}

static bool TraceItemClick(void *instance, void *list, void *item, int index,
                           int context, void *method)
{
    void *weaponList = nullptr;
    if (instance != nullptr)
        memcpy(&weaponList,
               static_cast<const unsigned char *>(instance) + 0x1C8,
               sizeof(weaponList));
    if (list == weaponList && index >= 0) {
        clickedCtrl.store(instance, std::memory_order_release);
        clickedIndex.store(index,   std::memory_order_release);
    }
    return orig_ItemClick != nullptr
        ? orig_ItemClick(instance, list, item, index, context, method) : false;
}

static uint32_t SelectedBlueprint(void *instance, uint32_t expectedBase,
                                   int &cardIndex, int &diyIndex)
{
    cardIndex = diyIndex = -1;
    if (instance == nullptr) return 0;
    const auto ctrl = static_cast<const unsigned char *>(instance);
    void *list = nullptr, *easyList = nullptr;
    memcpy(&list,     ctrl + 0x1D0, sizeof(list));
    memcpy(&easyList, ctrl + 0x1C8, sizeof(easyList));
    if (!list || !easyList) return 0;

    const auto listBytes = static_cast<const unsigned char *>(list);
    const auto easyBytes = static_cast<const unsigned char *>(easyList);
    void *items = nullptr;
    int count = 0, index = -1;
    memcpy(&items, listBytes + 0x10, sizeof(items));
    memcpy(&count, listBytes + 0x18, sizeof(count));
    memcpy(&index, easyBytes + 0x108, sizeof(index));
    if (clickedCtrl.load(std::memory_order_acquire) == instance)
        index = clickedIndex.load(std::memory_order_acquire);
    if (!items || count <= 0 || count > 4096 || index < 0 || index >= count)
        return 0;

    const auto array = static_cast<const unsigned char *>(items);
    size_t capacity = 0;
    memcpy(&capacity, array + 0x18, sizeof(capacity));
    if (static_cast<size_t>(index) >= capacity || capacity > 4096) return 0;

    void *entry = nullptr;
    memcpy(&entry,
           array + 0x20 + static_cast<size_t>(index) * sizeof(entry),
           sizeof(entry));
    if (!entry) return 0;

    const auto data = static_cast<const unsigned char *>(entry);
    uint32_t base = 0, blueprint = 0;
    memcpy(&base,      data + 0x20, sizeof(base));
    memcpy(&blueprint, data + 0x24, sizeof(blueprint));
    memcpy(&diyIndex,  data + 0x28, sizeof(diyIndex));
    if (blueprint == base) return 0;

    if (base != expectedBase) {
        std::lock_guard<std::mutex> lock(equippedMutex);
        const auto equipped = equippedBlueprints.find(base);
        if (equipped == equippedBlueprints.end() ||
            equipped->second.blueprint != expectedBase)
            return 0;
    }
    cardIndex = index;
    return blueprint;
}

static bool QueueBlueprint(uint32_t blueprintId)
{
    if (blueprintId == 0 || !CanUseBlueprint()) return false;
    OblivionSkinHax::gScanRequested.store(true, std::memory_order_release);
    pendingBlueprint.store(blueprintId, std::memory_order_release);
    return true;
}

static void TraceEquipStep(void *instance, int equipType, void *method)
{
    uint32_t selected = 0, switched = 0;
    if (instance != nullptr) {
        const auto bytes = static_cast<const unsigned char *>(instance);
        memcpy(&selected, bytes + 0x204, sizeof(selected));
        memcpy(&switched, bytes + 0x1E8, sizeof(switched));
    }
    int cardIndex = -1, diyIndex = -1;
    const uint32_t blueprint =
        SelectedBlueprint(instance, selected, cardIndex, diyIndex);
    if (blueprint != 0) {
        pendingBlueprintIndex.store(cardIndex, std::memory_order_release);
        pendingBlueprintDiy.store(diyIndex,   std::memory_order_release);
        if (QueueBlueprint(blueprint)) return;
        pendingBlueprintIndex.store(-1, std::memory_order_release);
        pendingBlueprintDiy.store(-1,   std::memory_order_release);
    }
    if (orig_EquipStep != nullptr)
        orig_EquipStep(instance, equipType, method);
}

static void TraceSafeHouseEquip(void *instance, void *method)
{
    if (orig_SafeHouseEquip != nullptr)
        orig_SafeHouseEquip(instance, method);
}

static void HookGunsmithEquip(void *instance, void *method)
{
    uint32_t selected = 0, switched = 0;
    if (instance != nullptr) {
        const auto bytes = static_cast<const unsigned char *>(instance);
        memcpy(&selected, bytes + 0x204, sizeof(selected));
        memcpy(&switched, bytes + 0x1E8, sizeof(switched));
    }
    if (QueueBlueprint(selected) ||
        (switched != selected && QueueBlueprint(switched)))
        return;
    if (orig_GunsmithEquip != nullptr)
        orig_GunsmithEquip(instance, method);
}

static void HookBlueprintEquip(void *instance, uint32_t blueprintId, void *method)
{
    if (instance != nullptr && QueueBlueprint(blueprintId)) return;
    if (orig_BlueprintEquip != nullptr)
        orig_BlueprintEquip(instance, blueprintId, method);
}

static void TraceSkinRes(void *instance, void *res, void *method)
{
    if (orig_SkinRes != nullptr)
        orig_SkinRes(instance, res, method);
}

inline void Install()
{
    const auto hook = [](uintptr_t rva, void *hk, void **orig) {
        const DWORD addr = getAbsoluteAddress("libunity.so", rva);
        if (addr != 0) DobbyHook((void *)addr, hk, orig);
    };

    hook(0x901F988, (void *)hooked_Unlockskin,      (void **)&original_Unlockskin);
    hook(0x5293B44, (void *)TraceSkinRes,            (void **)&orig_SkinRes);
    hook(0xA767CA4, (void *)HookBlueprintEquip,      (void **)&orig_BlueprintEquip);
    hook(0x5D0E574, (void *)HookGunsmithEquip,       (void **)&orig_GunsmithEquip);
    hook(0x5D0E6A0, (void *)TraceEquipStep,          (void **)&orig_EquipStep);
    hook(0xB86BE44, (void *)IsBlueprintEquipped,     (void **)&orig_IsEquipped);
    hook(0xB86BFD4, (void *)CardWeaponId,            (void **)&orig_WeaponId);
    hook(0xB86C0E0, (void *)CardWeaponName,          (void **)&orig_WeaponName);
    hook(0x5D0CAE4, (void *)IsWeaponEquipped,        (void **)&orig_EquipCheck);
    hook(0x5D1279C, (void *)TraceItemClick,          (void **)&orig_ItemClick);
    hook(0x6750500, (void *)TraceSafeHouseEquip,     (void **)&orig_SafeHouseEquip);
}

}
