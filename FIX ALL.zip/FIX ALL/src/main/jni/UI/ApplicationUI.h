#pragma once
#include "StudioComponents.h"
#include "../LoadingAnimation.h"
#include <string>
#include <fstream>
#include <cstdio>
#include <jni.h>

extern JavaVM *VM;

// UI only: the caller continues to own all values and feature callbacks.
namespace StudioUI {
static int Page=0;
static std::string AuthError;
static bool NavigationOpen=false;
static float NavigationProgress=0;
static ImVec2 MainPanelPos(0,0);
static ImVec2 MainPanelSize(0,0);
static const char* Pages[]={"Visuals","Movement","Aim","Memory","Settings","Skins"};
static const char* PageDetails[]={"Player overlays and visibility", "Movement and travel controls",
    "Assistance and targeting", "Weapon handling and items", "Performance and appearance",
    "Weapon skins and Mythic attachments"};
static const char* Sections[][4]={
    {"OVERLAY","ADDITIONAL VISIBILITY","OVERLAY COLORS",nullptr},
    {"SNOWBOARD","SLIDE","SPEED","JUMP"},
    {"ASSISTANCE","ADDITIONAL CONTROLS",nullptr,nullptr},
    {"WEAPON HANDLING","MOVEMENT AND ITEMS",nullptr,nullptr},
    {"PERFORMANCE","WORKSPACE","RENDERING",nullptr},
    {"WEAPON SKINS",nullptr,nullptr,nullptr}
};
static int SelectedProfile = 0;
static bool AutoProfileLoadAttempted = false;
static bool LoginAnimationStarted = false;
static std::string ConfigBasePath() { return PowerHaxConfigFilePath("wc_config.dat"); }
static std::string ActiveProfilePath() { return PowerHaxConfigFilePath("active_profile.dat"); }
static void LoadActiveProfileChoice() {
    const std::string path = ActiveProfilePath();
    if (path.empty()) return;
    std::ifstream f(path.c_str(), std::ios::binary);
    int value = 0;
    if (f.read(reinterpret_cast<char*>(&value), sizeof(value)) && value >= 0 && value <= 1)
        SelectedProfile = value;
}
static void SaveActiveProfileChoice() {
    if (!EnsurePowerHaxConfigDirectory()) return;
    const std::string path = ActiveProfilePath();
    if (path.empty()) return;
    std::ofstream f(path.c_str(), std::ios::binary | std::ios::trunc);
    if (f) f.write(reinterpret_cast<const char*>(&SelectedProfile), sizeof(SelectedProfile));
}
static std::string ProfilePath(int profile) {
    return PowerHaxConfigFilePath(profile == 0 ? "PowerHax_Profile1_BR.dat" : "PowerHax_Profile2_MP.dat");
}
static bool CopyConfigFile(const char* from, const char* to) {
    std::ifstream in(from, std::ios::binary);
    if(!in) return false;
    std::ofstream out(to, std::ios::binary | std::ios::trunc);
    if(!out) return false;
    out << in.rdbuf();
    return in.good() || in.eof() ? out.good() : false;
}
static bool SaveProfile(int profile) {
    if (!EnsurePowerHaxConfigDirectory() || !saveAllConfig()) return false;
    const std::string source = ConfigBasePath();
    const std::string target = ProfilePath(profile);
    if (source.empty() || target.empty()) return false;
    return CopyConfigFile(source.c_str(), target.c_str());
}
static bool LoadProfile(int profile) {
    const std::string source = ProfilePath(profile);
    const std::string target = ConfigBasePath();
    if (source.empty() || target.empty()) return false;
    if (!CopyConfigFile(source.c_str(), target.c_str())) return false;
    return loadAllConfig();
}
static void Visuals() {
    Section("OVERLAY");
    Toggle("Enable ESP", &Config.ESPMenu.Esp);
    Toggle("Player lines", &Config.ESPMenu.isPlayerLine);
    Toggle("Player boxes", &Config.ESPMenu.Box);
    Toggle("Health", &Config.ESPMenu.Health);
    Toggle("Names", &Config.ESPMenu.Name);
    Toggle("Distance", &Config.ESPMenu.Distance);
    Toggle("Off-screen alerts", &Config.ESPMenu.Alert);
    Toggle("Vehicles", &Config.ESPMenu.Vehicles);
    static const char* types[]={"Old type","Classic","Modern"};
    Choice("ESP presentation",Config.WIDGETS_EXPERT.EUI,types,3);
    Section("ADDITIONAL VISIBILITY");
    Toggle("Spectate without delay",&Config.ExtraMenu.Spectate);
    Toggle("Wallhack glow",&checkboxStates["wallhack"]);
    Toggle("Multiplayer radar",&Config.ExtraMenu.Radar1);
    Toggle("Royale tags",&checkboxStates["BRTAGS"]);
    Section("OVERLAY COLORS");
    if(ImGui::CollapsingHeader("Player colors")) {
        Color("Player box",Config.sColorsESPPLAYER.BoxPLAYER);
        Color("Player line",Config.sColorsESPPLAYER.LinePLAYER);
        Color("Player name",Config.sColorsESPPLAYER.NamePLAYER);
        Color("Player health",Config.sColorsESPPLAYER.HealthPLAYER);
        Color("Player distance",Config.sColorsESPPLAYER.DistancePLAYER);
        EndGrid();
    }
    if(ImGui::CollapsingHeader("Bot colors")) {
        Color("Bot box",Config.sColorsESPBOT.BoxBOT);
        Color("Bot line",Config.sColorsESPBOT.LineBOT);
        Color("Bot name",Config.sColorsESPBOT.NameBOT);
        Color("Bot health",Config.sColorsESPBOT.HealthBOT);
        Color("Bot distance",Config.sColorsESPBOT.DistanceBOT);
        EndGrid();
    }
}
static void Movement() {
    Section("SNOWBOARD");
    if(Toggle("Snowboard boost",&SnowB)) SnowBshow=SnowB;
    if(SnowBshow) Slider("Boost",&SnowBsize,0,100);
    Section("SLIDE");
    if(Toggle("Long slide",&SlideTackle)) SlideShow=SlideTackle;
    if(SlideShow) Slider("Slide range",&SlideRange,0,30);
    Section("SPEED");
if (Toggle("Speed hack", &isSpeedHackEnabled))
    showSpeedHackSlider = isSpeedHackEnabled;
if (showSpeedHackSlider)
    Slider("Speed multiplier", &Config.ExtraMenu.SpeedhackValue, speed_min, speed_max, "%.1fx");
    Section("JUMP");
    if(Toggle("High jump",&isJumpAdjustmentEnabled) && !isJumpAdjustmentEnabled) jumpHeightMultiplier=1;
    if(isJumpAdjustmentEnabled) Slider("Jump multiplier",&jumpHeightMultiplier,.5f,5,"%.1fx");
}
static void AimControls() {
    Section("ASSISTANCE");
    if(Toggle("Aimlock",&Config.Aim.AimAssist)) Config.Aim.showAimAssistSlider=Config.Aim.AimAssist;
    Slider("Smoothness",&Config.Aim.AimAssistSize,0,100,"%.0f");
    Slider("Field of view",&Config.Aim.size,0,500,"%.0f");
    static const char* targets[]={"Head","Chest"};
    // The backend defines exactly these three activation values.
    static const char* triggers[]={"Always","Fire","Scope"};
    Choice("Target",Config.Aim.Target,targets,2);
    Choice("Activation",Config.Aim.Trigger,triggers,3);
    Section("ADDITIONAL CONTROLS");
    // These existing keys intentionally retain the original label-to-state mapping.
    Toggle("Aimbot 360",&Config.Aim.Aimbot360);
    Toggle("Bullet track",&Config.Aim.AimSilent);
    Toggle("Fast revival",&Config.ExtraMenu.Revive);
    Toggle("Fast medicine",&Config.ExtraMenu.Medicine);
}
static void MemoryControls() {
    Section("WEAPON HANDLING");
    Toggle("Weapon kinetic",&Config.ExtraMenu.Kinetic);
    Toggle("No recoil",&Config.ExtraMenu.Recoil);
    Toggle("No spread",&Config.ExtraMenu.Spread);
    Toggle("No reload",&Config.ExtraMenu.Reload);
    Toggle("No scope",&Config.ExtraMenu.Scope);
    Toggle("No switch",&Config.ExtraMenu.Switch);
    Toggle("No shake",&Config.ExtraMenu.Shake);
    Toggle("Unlimited bullets",&checkboxStates["AMMO"]);
    Toggle("No overheat",&Config.ExtraMenu.Rpd);
    Toggle("Long range",&Config.ExtraMenu.Range);
    Toggle("Instant shot",&Config.ExtraMenu.AutoSnipe);
    Toggle("Big hitbox",&Config.ExtraMenu.Hit);
    Toggle("HIDE RECORD",&HIDEESP);
    Toggle("Quick firing",&Config.ExtraMenu.Auto);
    Section("MOVEMENT AND ITEMS");
    Toggle("Jet boost + slide",&Config.ExtraMenu.JetS);
    Toggle("Long execute",&isExecute);
    Toggle("No parachute",&Config.ExtraMenu.Parachute);
    Toggle("Sky diving speed",&Config.ExtraMenu.Diving);
    Toggle("Two Gulag tickets",&Config.ExtraMenu.TestGulag);
    Toggle("Magnet loot",&Config.ExtraMenu.MagnetLoot);
    Toggle("Fast loot",&Config.ExtraMenu.FastLoot);
    Toggle("Jet boost + jump",&Config.ExtraMenu.JetJ);
}
static void SystemControls() {
    Section("PERFORMANCE");
    Toggle("Unlock Blueprint",&Config.ExtraMenu.UnlockBlueprint);
    Toggle("Anti FPS drop",&checkboxStates["anti"]);
    Toggle("Maximum frame rate",&checkboxStates["FRAMERATE"]);

    Section("WORKSPACE");
    Toggle("Show floating control",&showFloatingIcon);
    Color("Interface accent",menu);

    Section("SETTINGS PROFILE");
    const char* profileNames[] = {"Profile 1 - BR", "Profile 2 - MP"};
    ImGui::SetNextItemWidth(-1);
    if (ImGui::BeginCombo("##profile_select", profileNames[SelectedProfile])) {
        for (int i=0; i<2; ++i) {
            const bool selected = (SelectedProfile == i);
            if (ImGui::Selectable(profileNames[i], selected)) { SelectedProfile = i; SaveActiveProfileChoice(); }
            if (selected) ImGui::SetItemDefaultFocus();
        }
        ImGui::EndCombo();
    }
    const float actionButtonW=(ImGui::GetContentRegionAvail().x-S(10))*0.5f;
    if (Button("Save", ImVec2(actionButtonW, S(42)), true)) {
        SaveActiveProfileChoice();
        AuthError = SaveProfile(SelectedProfile) ? "Selected setup saved on this device." : "Save failed. App-private storage could not be written.";
    }
    ImGui::SameLine(0,S(10));
    if (Button("Load", ImVec2(actionButtonW, S(42)))) {
        SaveActiveProfileChoice();
        AuthError = LoadProfile(SelectedProfile) ? "Selected setup loaded." : "Load failed. This profile may not have been saved yet.";
    }
    if (!AuthError.empty() && AuthError != "OK") ImGui::TextWrapped("%s", AuthError.c_str());

    Section("RENDERING");
    ImGui::TextUnformatted("FPS target preference");
    const float fpsButtonW=(ImGui::GetContentRegionAvail().x-S(10))*0.5f;
    if(Button("120 FPS",ImVec2(fpsButtonW,S(42)),Config.Aim.FpsLevel1==120.0f)) {
        Config.Aim.FpsLevel1=120.0f; Config.Aim.FpsLevel=true;
    }
    ImGui::SameLine(0,S(10));
    if(Button("180 FPS",ImVec2(fpsButtonW,S(42)),Config.Aim.FpsLevel1==180.0f)) {
        Config.Aim.FpsLevel1=180.0f; Config.Aim.FpsLevel=true;
    }
    ImGui::TextWrapped("Choose a target supported by your device and game. This sets the app's FPS preference; actual FPS depends on device, display, game settings, and backend support.");

    Toggle("Stretch Screen",&Config.ExtraMenu.StretchScreen);

if (Config.ExtraMenu.StretchScreen)
    Slider("Stretch Aspect", &Config.ExtraMenu.StretchAspect, 0.5f, 3.0f, "%.2f");

    const float fps=ImGui::GetIO().Framerate;
    ImGui::Text("%.0f FPS   /   %.2f ms per frame",
                fps,
                fps>0?1000.0f/fps:0);

    ImGui::TextWrapped(
        "The home bar always stays available. Swipe up or tap it to browse tabs and sections."
    );
}


static void SkinHaxControls() {
    // DrawPanel owns its search, rarity boxes, list and apply action. Keep it out
    // of the generic two-column settings grid so the weapon list gets full width.
    EndGrid();
#ifdef STUDIO_STANDALONE_PREVIEW
    Section("WEAPON SKINS");
    ImGui::TextWrapped("SkinHax runtime data is available in the production game build.");
#else
    OblivionSkinHax::DrawPanel(Scale);
#endif
}

static int EnabledCount(int page) {
    switch(page) {
        case 0: return Config.ESPMenu.Esp+Config.ESPMenu.isPlayerLine+Config.ESPMenu.Box+
            Config.ESPMenu.Health+Config.ESPMenu.Name+Config.ESPMenu.Distance+Config.ESPMenu.Alert+
            Config.ESPMenu.Vehicles+Config.ExtraMenu.Spectate+checkboxStates["wallhack"]+
            Config.ExtraMenu.Radar1+checkboxStates["BRTAGS"];
        case 1: return SnowB+SlideTackle+isSpeedHackEnabled+isJumpAdjustmentEnabled;
        case 2: return Config.Aim.AimAssist+Config.Aim.Aimbot360+Config.Aim.AimSilent+Config.ExtraMenu.Revive+Config.ExtraMenu.Medicine;
        case 3: return Config.ExtraMenu.Kinetic+Config.ExtraMenu.Recoil+Config.ExtraMenu.Spread+
            Config.ExtraMenu.Reload+Config.ExtraMenu.Scope+Config.ExtraMenu.Switch+Config.ExtraMenu.Shake+
            checkboxStates["AMMO"]+Config.ExtraMenu.Rpd+Config.ExtraMenu.Range+Config.ExtraMenu.AutoSnipe+
            Config.ExtraMenu.Hit+Config.ExtraMenu.Auto+Config.ExtraMenu.JetS+isExecute+
            Config.ExtraMenu.Parachute+Config.ExtraMenu.Diving+Config.ExtraMenu.TestGulag+
            Config.ExtraMenu.MagnetLoot+Config.ExtraMenu.FastLoot+Config.ExtraMenu.JetJ;
case 4: return checkboxStates["highend"]
    + checkboxStates["anti"]
    + checkboxStates["FRAMERATE"]
    + showFloatingIcon
    + Config.ExtraMenu.StretchScreen;
        case 5:
#ifdef STUDIO_STANDALONE_PREVIEW
            return 0;
#else
            return OblivionSkinHax::gHasSelectedSkin ? 1 : 0;
#endif
        default: return 0;
    }
}
static void PreviewBackdrop() {
#ifdef STUDIO_STANDALONE_PREVIEW
    auto* d=ImGui::GetBackgroundDrawList();
    const ImVec2 size=ImGui::GetIO().DisplaySize;
    d->AddRectFilledMultiColor(ImVec2(0,0),size,IM_COL32(22,28,39,255),IM_COL32(33,40,45,255),
                              IM_COL32(13,19,25,255),IM_COL32(22,21,33,255));
    struct Light { float x,y,r; int red,green,blue; };
    const Light lights[]={{.15f,.35f,.46f,112,60,172},{.78f,.35f,.43f,10,113,123},
                          {.81f,.79f,.41f,174,52,88},{.30f,.86f,.3f,16,125,105}};
    const float side=std::min(size.x,size.y);
    for(const auto& light:lights) {
        for(int ring=26;ring>0;--ring) {
            const float t=ring/26.f;
            d->AddCircleFilled(ImVec2(size.x*light.x,size.y*light.y),side*light.r*t,
                IM_COL32(light.red,light.green,light.blue,5),64);
        }
    }
#endif
}
#ifndef STUDIO_STANDALONE_PREVIEW
// Resolve the current Android process' private files directory through JNI.
// A hard-coded /data/data/<package> path can fail when this native UI runs in
// a different process/package, which was why the previous version did not save.
static std::string RememberKeyPath() {
    static std::string cachedPath;
    if (!cachedPath.empty()) return cachedPath;
    if (!VM) return std::string();

    JNIEnv *env = nullptr;
    bool attachedHere = false;
    jint status = VM->GetEnv(reinterpret_cast<void **>(&env), JNI_VERSION_1_6);
    if (status == JNI_EDETACHED) {
        if (VM->AttachCurrentThread(&env, nullptr) != JNI_OK) return std::string();
        attachedHere = true;
    } else if (status != JNI_OK || !env) {
        return std::string();
    }

    jclass activityThread = env->FindClass("android/app/ActivityThread");
    jmethodID currentApplication = activityThread ? env->GetStaticMethodID(
        activityThread, "currentApplication", "()Landroid/app/Application;") : nullptr;
    jobject app = currentApplication ? env->CallStaticObjectMethod(activityThread, currentApplication) : nullptr;
    jclass contextClass = app ? env->GetObjectClass(app) : nullptr;
    jmethodID getFilesDir = contextClass ? env->GetMethodID(contextClass, "getFilesDir", "()Ljava/io/File;") : nullptr;
    jobject filesDir = getFilesDir ? env->CallObjectMethod(app, getFilesDir) : nullptr;
    jclass fileClass = filesDir ? env->GetObjectClass(filesDir) : nullptr;
    jmethodID getAbsolutePath = fileClass ? env->GetMethodID(fileClass, "getAbsolutePath", "()Ljava/lang/String;") : nullptr;
    jstring path = getAbsolutePath ? (jstring)env->CallObjectMethod(filesDir, getAbsolutePath) : nullptr;
    if (!env->ExceptionCheck() && path) {
        const char *utf = env->GetStringUTFChars(path, nullptr);
        if (utf) {
            cachedPath.assign(utf);
            env->ReleaseStringUTFChars(path, utf);
            cachedPath += "/remember_key.txt";
        }
    }
    if (env->ExceptionCheck()) env->ExceptionClear();
    if (path) env->DeleteLocalRef(path);
    if (fileClass) env->DeleteLocalRef(fileClass);
    if (filesDir) env->DeleteLocalRef(filesDir);
    if (contextClass) env->DeleteLocalRef(contextClass);
    if (app) env->DeleteLocalRef(app);
    if (activityThread) env->DeleteLocalRef(activityThread);
    if (attachedHere) VM->DetachCurrentThread();
    return cachedPath;
}
static bool RememberKeyLoadOnce() {
    static bool loaded = false;
    static bool remember = false;
    if (!loaded) {
        loaded = true;
        const std::string path = RememberKeyPath();
        if (!path.empty()) {
            std::ifstream in(path.c_str(), std::ios::in);
            if (in.good()) {
                in.getline(s, sizeof(s));
                remember = (s[0] != '\0');
            }
        }
    }
    return remember;
}
static void RememberKeySave(bool enabled) {
    const std::string path = RememberKeyPath();
    if (path.empty()) return;
    if (enabled && s[0] != '\0') {
        std::ofstream out(path.c_str(), std::ios::out | std::ios::trunc);
        if (out.good()) out << s << '\n';
    } else if (!enabled) {
        std::remove(path.c_str());
    }
}
static void LoginPanel() {
    static bool rememberKey = false;
    static bool rememberKeyInitialized = false;
    if (!rememberKeyInitialized) {
        rememberKey = RememberKeyLoadOnce();
        rememberKeyInitialized = true;
    }
    const ImVec2 display=UsableDisplaySize();
    // Compact login panel: fit the content area shown in the reference screenshot.
    // Keep width and all controls unchanged; remove the unused vertical space.
    const ImVec2 size(std::min(S(460),display.x-S(24)),std::min(S(300),display.y-S(30)));
    ImGui::SetNextWindowSize(size,ImGuiCond_Always);
    ImGui::SetNextWindowPos(ImVec2(display.x*.5f,display.y*.5f),ImGuiCond_Always,ImVec2(.5f,.5f));
    if(ImGui::Begin("##glass_access",nullptr,ImGuiWindowFlags_NoDecoration|ImGuiWindowFlags_NoSavedSettings)) {
        ImGui::SetWindowFontScale(Scale*18.f/22.f);
        auto* d=ImGui::GetWindowDrawList();
        d->AddRectFilled(ImGui::GetWindowPos(),Add(ImGui::GetWindowPos(),size),IM_COL32(19,24,32,238),S(32));
        Glass(d,ImGui::GetWindowPos(),size,32);
        Heading("POWERHAX", "Enter your license key to open the control center.");
        ImGui::TextUnformatted("License key");
        static bool showLicenseKey=false;
        const float keyButtonW=S(92.f);
        ImGui::SetNextItemWidth(-keyButtonW-S(8.f));
        if (ImGui::InputTextWithHint("##license","Paste or enter your key",s,sizeof(s),
                showLicenseKey ? ImGuiInputTextFlags_None : ImGuiInputTextFlags_Password) && rememberKey)
            RememberKeySave(true);
        ImGui::SameLine(0,S(8.f));
        if(Button(showLicenseKey?"Hide":"Show",ImVec2(keyButtonW,S(38.f)))) showLicenseKey=!showLicenseKey;
        // Full-width animated equalizer accent for the license-key field.
        // It is decorative only and never draws or exposes the key contents.
        {
            const ImVec2 fieldMin=ImGui::GetItemRectMin();
            const ImVec2 fieldMax=ImGui::GetItemRectMax();
            ImDrawList* wave=ImGui::GetWindowDrawList();
            const float mid=(fieldMin.y+fieldMax.y)*.5f;
            const float width=fieldMax.x-fieldMin.x;
            const float t=(float)ImGui::GetTime();
            const int bars=std::max(12,(int)(width/S(8.f)));
            for(int i=0;i<bars;++i) {
                const float x=fieldMin.x+S(4.f)+((width-S(8.f))*i/(float)bars);
                const float h=S(2.f)+S(5.f)*(.5f+.5f*std::sin(t*5.f+i*.72f));
                wave->AddLine(ImVec2(x,mid-h),ImVec2(x,mid+h),IM_COL32(218,170,61,110),S(1.2f));
            }
        }
        if (ImGui::Checkbox("Remember key", &rememberKey)) {
            RememberKeySave(rememberKey);
        }
        if (rememberKey) RememberKeySave(true);
        const float half=(ImGui::GetContentRegionAvail().x-S(12))*.5f;
        if(Button("Paste key",ImVec2(half,S(44)))) {
            const std::string key=getClipboard();
            std::snprintf(s,sizeof(s),"%s",key.c_str());
            if (rememberKey) RememberKeySave(true);
        }
        ImGui::SameLine(0,S(12));
        if(Button("Continue",ImVec2(half,S(44)),true)) {
            AuthError=Login(s);
            if(AuthError=="OK") isLogin=bValid && g_Auth==g_Token;
            if(AuthError=="OK" && !isLogin) AuthError="Session verification failed.";
            if (isLogin && !LoginAnimationStarted) {
                ui_loading::Start(8.0f);
                LoginAnimationStarted = true;
            }
        }
        ImGui::TextWrapped("Paste your PowerHAX Key and Continue to Access.");
        if(!AuthError.empty() && AuthError!="OK") {
            ImGui::PushStyleColor(ImGuiCol_Text,ImVec4(1,.62f,.60f,1));
            ImGui::TextWrapped("%s",AuthError.c_str()); ImGui::PopStyleColor();
        }
    }
    ImGui::End();
}
#endif
static void DrawPage() {
    CurrentIcon=Page; ExclusiveDrag=false;
    switch(Page) {
        case 0: Visuals(); break;
        case 1: Movement(); break;
        case 2: AimControls(); break;
        case 3: MemoryControls(); break;
        case 4: SystemControls(); break;
        case 5: SkinHaxControls(); break;
    }
    EndGrid();
}
static void ControlCenter() {
    const ImVec2 display=UsableDisplaySize();
    // Keep the settings window independent from the radial selector. In landscape,
    // reserve a dedicated column on the left for the floating radial window.
    const float radialColumn=S(430)+S(22);
    const bool sideBySide=display.x>S(1050);
    const float available=display.x-S(24)-(sideBySide?radialColumn:0.f);
    const ImVec2 size(std::min(S(sideBySide?850:1040),available),display.y-S(68));
    const ImVec2 pos(sideBySide ? (display.x-(size.x+radialColumn))*.5f+radialColumn : (display.x-size.x)*.5f,S(12));
    MainPanelPos=pos; MainPanelSize=size;
    ImGui::SetNextWindowPos(pos,ImGuiCond_Always);
    ImGui::SetNextWindowSize(size,ImGuiCond_Always);
    ImGuiWindowFlags flags=ImGuiWindowFlags_NoDecoration|ImGuiWindowFlags_NoMove|ImGuiWindowFlags_NoSavedSettings;
    // The detached radial selector is the only tab-navigation control.
    if(ImGui::Begin("##white_crowns",nullptr,flags)) {
        ImGui::SetWindowFontScale(Scale*18.f/22.f);
        auto* d=ImGui::GetWindowDrawList();
        d->AddRectFilled(pos,Add(pos,size),IM_COL32(5,9,25,250),S(18));
        d->AddRect(pos,Add(pos,size),IM_COL32(157,117,34,235),S(18),0,S(1.3f));
        const bool narrow=size.x<S(650);
        const float headerHeight=S(narrow?90:82);
        Text(d,Add(pos,V(22,14)),12,IM_COL32(230,190,91,255),"POWERHAX  /  SSSVIP");
        Text(d,Add(pos,V(22,34)),narrow?24:29,Ink(),"POWERHAX MENU",size.x-S(180),true);
        Text(d,Add(pos,V(24,narrow?64:62)),11,Muted(),"CONTROL CENTER  /  SECURE SESSION");

        // Top-right status and hide controls, styled after the supplied reference.
        ImGui::SetCursorPos(ImVec2(size.x-S(126),S(18)));
        Tap("##vip",V(70,30));
        Glass(d,ImVec2(pos.x+size.x-S(126),pos.y+S(18)),V(70,30),15,true,ImGui::IsItemHovered());
        Text(d,ImVec2(pos.x+size.x-S(115),pos.y+S(27)),10,Ink(),"SSSVIP");
        ImGui::SetCursorPos(ImVec2(size.x-S(48),S(14)));
        if(Tap("##close",V(34,34))) { show=false; NavigationOpen=false; ResetGestures(); }
        Glass(d,ImVec2(pos.x+size.x-S(48),pos.y+S(14)),V(34,34),9,false,ImGui::IsItemHovered());
        d->AddLine(ImVec2(pos.x+size.x-S(39),pos.y+S(31)),ImVec2(pos.x+size.x-S(23),pos.y+S(31)),Ink(),S(2));

        const float bodyY=headerHeight;
        const float bodyH=std::max(S(80),size.y-bodyY-S(42));
        // Navigation is rendered in its own floating window by RadialMenu().
        const float contentX=S(12);
        const float contentWidth=size.x-contentX-S(12);
        ImGui::SetCursorPos(ImVec2(contentX,bodyY/Scale));
        ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding,V(10,8));
        ImGui::PushID(Page);
        if(ImGui::BeginChild("##settings",ImVec2(contentWidth,std::max(S(30),bodyH)),false,
                             ImGuiWindowFlags_AlwaysUseWindowPadding|ImGuiWindowFlags_NoBackground)) {
            // Tab selection lives exclusively in the detached RadialMenu window.
            DrawPage();
            if(!NavigationOpen && NavigationProgress<.01f) ContentScroll();
        }
        ImGui::EndChild(); ImGui::PopID(); ImGui::PopStyleVar();

        // Bottom status strip mirrors the compact telemetry bar in the reference.
        const float fy=size.y-S(31);
        d->AddRectFilled(ImVec2(pos.x+S(14),pos.y+fy),ImVec2(pos.x+size.x-S(14),pos.y+fy+S(20)),IM_COL32(8,13,31,245),S(7));
        d->AddRect(ImVec2(pos.x+S(14),pos.y+fy),ImVec2(pos.x+size.x-S(14),pos.y+fy+S(20)),IM_COL32(123,94,31,190),S(7),0,S(1));
        Text(d,ImVec2(pos.x+S(26),pos.y+fy+S(5)),9,IM_COL32(230,190,91,255),"SYSTEM STATUS");
        Text(d,ImVec2(pos.x+S(120),pos.y+fy+S(5)),9,Muted(),"READY");
        Text(d,ImVec2(pos.x+size.x-S(156),pos.y+fy+S(5)),9,IM_COL32(230,190,91,255),"POWERHAX UI");
        Text(d,ImVec2(pos.x+size.x-S(72),pos.y+fy+S(5)),9,Muted(),"ACTIVE");
    }
    ImGui::End();
}
static void RadialMenu() {
    const ImVec2 display=UsableDisplaySize();
    if(display.x<S(100) || display.y<S(140)) return;
    const float panelW=S(430), panelH=std::min(S(430),display.y-S(40));
    const bool sideBySide=display.x>S(1050);
    static ImVec2 radialOffset(0,0);
    ImVec2 p;
    if(sideBySide) {
        p=ImVec2(MainPanelPos.x-panelW-S(14), MainPanelPos.y+(MainPanelSize.y-panelH)*.5f);
    } else {
        // On portrait/narrow displays the selector remains a separate floating card
        // near the left edge rather than being embedded in the settings panel.
        p=ImVec2(S(10),std::max(S(54),(display.y-panelH)*.5f));
    }
    // The center POWER/HAX hub is the drag handle. Offset persists while this UI runs.
    p.x=std::max(0.f,std::min(std::max(0.f,display.x-panelW),p.x+radialOffset.x));
    p.y=std::max(0.f,std::min(std::max(0.f,display.y-panelH),p.y+radialOffset.y));
    ImGui::SetNextWindowPos(p,ImGuiCond_Always);
    ImGui::SetNextWindowSize(ImVec2(panelW,panelH),ImGuiCond_Always);
    const ImGuiWindowFlags flags=ImGuiWindowFlags_NoDecoration|ImGuiWindowFlags_NoMove|
        ImGuiWindowFlags_NoSavedSettings|ImGuiWindowFlags_NoBackground|ImGuiWindowFlags_NoScrollbar;
    if(ImGui::Begin("##floating_radial",nullptr,flags)) {
        ImGui::SetWindowFontScale(Scale*18.f/22.f);
        auto* d=ImGui::GetWindowDrawList();
        const char* navNames[]={"VISUALS","MOVE","AIM","MEMORY","SETTINGS","SKINS"};
        const char* navHints[]={"OVERLAY","MOTION","TARGET","ITEMS","SYSTEM","STYLE"};
        const float cx=panelW/Scale*.5f;
        const float cy=panelH/Scale*.5f;
        const float radius=std::min(125.f,std::max(92.f,(panelH/Scale-150.f)*.34f));
        const float rotation=(float)ImGui::GetTime()*18.0f;
        const float angles[]={-90.f,-30.f,30.f,90.f,150.f,210.f};
        const ImVec2 hub(p.x+S(cx),p.y+S(cy));
        d->AddCircle(hub,S(radius+43),IM_COL32(38,42,99,175),72,S(1));
        d->AddCircle(hub,S(radius+34),IM_COL32(218,170,61,160),72,S(1.2f));
        // Spinning radial-wheel accents around the center hub.
        for(int tick=0;tick<12;++tick) {
            const float a=(rotation+tick*30.0f)*3.14159265f/180.0f;
            const ImVec2 a1(hub.x+std::cos(a)*S(radius+26),hub.y+std::sin(a)*S(radius+26));
            const ImVec2 a2(hub.x+std::cos(a)*S(radius+31),hub.y+std::sin(a)*S(radius+31));
            d->AddLine(a1,a2,IM_COL32(245,204,103,230),S(1.5f));
        }
        for(int i=0;i<6;++i) {
            const float a=(angles[i]+rotation)*3.14159265f/180.f;
            const float nx=cx+std::cos(a)*radius;
            const float ny=cy+std::sin(a)*radius;
            const ImVec2 center(p.x+S(nx),p.y+S(ny));
            d->AddLine(hub,center,IM_COL32(74,70,145,190),S(1));
            ImGui::PushID(i+100);
            ImGui::SetCursorPos(V(nx-67.f,ny-55.f));
            // Enlarged by approximately 0.5 inch in both dimensions for easier touch input.
            const ImVec2 itemSize=V(134,110);
            const ImVec2 mouseNow=ImGui::GetIO().MousePos;
            const float hubDx=mouseNow.x-hub.x, hubDy=mouseNow.y-hub.y;
            const bool pointerOverHub=(hubDx*hubDx+hubDy*hubDy)<=S(43)*S(43);
            // While the pointer is over the center hub, reserve the gesture for hold-to-move
            // instead of allowing overlapping radial tile hitboxes to change pages.
            if(pointerOverHub) ImGui::Dummy(itemSize);
            else if(Tap("##radial_item",itemSize)) { Page=i; PendingSection=nullptr; ResetGestures(); }
            const ImVec2 item(p.x+S(nx-67.f),p.y+S(ny-55.f));
            // No tile background: retain itemSize and Tap() for unchanged touch targets.
            const ImU32 iconColor=Page==i?IM_COL32(255,220,130,255):IM_COL32(151,164,207,255);
            d->AddCircle(ImVec2(center.x,center.y-S(7)),S(12),Page==i?IM_COL32(226,174,58,255):IM_COL32(72,87,145,255),28,S(1.3f));
            Icon(d,ImVec2(center.x-S(8),center.y-S(15)),S(16),i==4?4:(i==5?3:i),iconColor);
            // Use the angular display typeface for radial labels, matching the POWERHAX
            // reference design while keeping the labels clear at small screen sizes.
            const ImVec2 labelSize=TitleFont->CalcTextSizeA(S(10.f),FLT_MAX,0,navNames[i]);
            Text(d,ImVec2(center.x-labelSize.x*.5f,center.y+S(10)),10.f,Page==i?Ink():Muted(),navNames[i],0,true);
            ImGui::PopID();
        }
        // Hold the center POWER/HAX hub briefly, then drag to move the entire radial menu.
        // A short press remains harmless and does not move the menu accidentally.
        const ImGuiIO& io=ImGui::GetIO();
        const float hubDx=io.MousePos.x-hub.x, hubDy=io.MousePos.y-hub.y;
        const bool pointerOverHub=(hubDx*hubDx+hubDy*hubDy)<=S(43)*S(43);
        static bool radialMoveActive=false;
        static bool radialHoldConsumed=false;
        if(ImGui::IsMouseClicked(0)) { radialMoveActive=false; radialHoldConsumed=false; }
        if(io.MouseDown[0] && pointerOverHub && io.MouseDownDuration[0]>=0.30f) {
            radialMoveActive=true;
            radialHoldConsumed=true;
        }
        if(radialMoveActive && io.MouseDown[0]) {
            radialOffset.x+=io.MouseDelta.x;
            radialOffset.y+=io.MouseDelta.y;
        }
        if(ImGui::IsMouseReleased(0)) {
            radialMoveActive=false;
            radialHoldConsumed=false;
        }
        d->AddCircleFilled(hub,S(35),IM_COL32(12,18,43,255),48);
        d->AddCircle(hub,S(35),IM_COL32(235,186,72,255),48,S(2.5f));
        d->AddCircle(hub,S(27),IM_COL32(59,51,126,255),48,S(1.3f));
        const char* hubText="POWER";
        const ImVec2 hubTextSize=TitleFont->CalcTextSizeA(S(11),FLT_MAX,0,hubText);
        Text(d,ImVec2(hub.x-hubTextSize.x*.5f,hub.y-S(7)),11,Ink(),hubText,0,true);
        const char* hubSub="HAX";
        const ImVec2 hubSubSize=TitleFont->CalcTextSizeA(S(8.5f),FLT_MAX,0,hubSub);
        Text(d,ImVec2(hub.x-hubSubSize.x*.5f,hub.y+S(7)),8.5f,IM_COL32(230,190,91,255),hubSub,0,true);
    }
    ImGui::End();
}

static void NavigationSheet() {
    const float target=NavigationOpen?1.f:0.f;
    NavigationProgress+=(target-NavigationProgress)*std::min(1.f,ImGui::GetIO().DeltaTime*19.f);
    if(std::fabs(NavigationProgress-target)<.005f) NavigationProgress=target;
    if(NavigationProgress<=.001f) return;
    const ImVec2 display=UsableDisplaySize();
    const bool narrow=display.x<S(600);
    const ImVec2 size(std::min(S(790),display.x-S(24)),std::min(S(narrow?485:380),display.y-S(100)));
    const ImVec2 p((display.x-size.x)*.5f,display.y-S(62)-size.y+(1-NavigationProgress)*size.y);
    ImGui::SetNextWindowPos(ImVec2(0,0)); ImGui::SetNextWindowSize(display);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding,ImVec2(0,0));
    const ImGuiWindowFlags flags=ImGuiWindowFlags_NoDecoration|ImGuiWindowFlags_NoMove|
        ImGuiWindowFlags_NoSavedSettings|ImGuiWindowFlags_NoBackground;
    if(ImGui::Begin("##navigation_backdrop",nullptr,flags)) {
        ImGui::GetWindowDrawList()->AddRectFilled(ImVec2(0,0),display,IM_COL32(3,6,12,(int)(160*NavigationProgress)));
        if(ImGui::InvisibleButton("##dismiss",display)) NavigationOpen=false;
    }
    ImGui::End(); ImGui::PopStyleVar();
    ImGui::SetNextWindowPos(p); ImGui::SetNextWindowSize(size);
    if(ImGui::Begin("##glass_navigation",nullptr,flags)) {
        ImGui::SetWindowFontScale(Scale*18.f/22.f);
        auto* d=ImGui::GetWindowDrawList();
        d->PushClipRect(p,Add(p,size),false);
        d->AddRectFilled(p,Add(p,size),IM_COL32(29,36,48,249),S(32));
        Glass(d,p,size,32);
        d->PopClipRect();
        ImGui::SetCursorPos(V(0,0));
        const bool handle=ImGui::InvisibleButton("##sheet_handle",ImVec2(size.x,S(32)));
        if((ImGui::IsItemActive() && ImGui::GetMouseDragDelta(0).y>S(28)) || handle) NavigationOpen=false;
        d->AddRectFilled(ImVec2(p.x+size.x*.5f-S(23),p.y+S(12)),ImVec2(p.x+size.x*.5f+S(23),p.y+S(16)),IM_COL32(238,244,255,160),S(2));
        Text(d,Add(p,V(22,39)),25,Ink(),"Navigation",0,true);
        Text(d,Add(p,V(22,72)),13,Muted(),"Choose a tab, then jump to a section.",size.x-S(44));
        ImGui::SetCursorPos(V(16,102));
        if(ImGui::BeginChild("##nav_content",ImVec2(size.x-S(32),size.y-S(116)),false)) {
            auto* tileDraw=ImGui::GetWindowDrawList();
            const int columns=narrow?3:5;
            if(ImGui::BeginTable("##tabs",columns,ImGuiTableFlags_SizingStretchSame)) {
                for(int i=0;i<6;++i) {
                    ImGui::TableNextColumn(); ImGui::PushID(i);
                    const ImVec2 tile=ImGui::GetCursorScreenPos();
                    const ImVec2 tileSize(ImGui::GetContentRegionAvail().x,S(86));
                    if(Tap("##tab",tileSize)) { Page=i; PendingSection=nullptr; ResetGestures(); }
                    Glass(tileDraw,tile,tileSize,23,Page==i,ImGui::IsItemHovered());
                    Icon(tileDraw,ImVec2(tile.x+tileSize.x*.5f-S(13),tile.y+S(12)),S(26),i,Ink());
                    const float textWidth=BodyFont->CalcTextSizeA(S(14),FLT_MAX,0,Pages[i]).x;
                    Text(tileDraw,ImVec2(tile.x+(tileSize.x-textWidth)*.5f,tile.y+S(49)),14,Ink(),Pages[i]);
                    if(Page==i) tileDraw->AddCircleFilled(ImVec2(tile.x+tileSize.x*.5f,tile.y+S(75)),S(2),Ink(),12);
                    ImGui::PopID();
                }
                ImGui::EndTable();
            }
            ImGui::Spacing();
            ImGui::Text("%s sections",Pages[Page]);
            if(ImGui::BeginTable("##sections",narrow?1:2,ImGuiTableFlags_SizingStretchSame)) {
                for(int i=0;i<4 && Sections[Page][i];++i) {
                    ImGui::TableNextColumn();
                    if(Button(Sections[Page][i],ImVec2(-1,S(42)))) {
                        PendingSection=Sections[Page][i]; NavigationOpen=false;
                    }
                }
                ImGui::EndTable();
            }
            if(Button("Open selected tab",ImVec2(-1,S(44)),true)) NavigationOpen=false;
            ExclusiveDrag=false; ContentScroll();
        }
        ImGui::EndChild();
    }
    ImGui::End();
}
static void HomeBar() {
    const ImVec2 display=UsableDisplaySize();
    const float diameter=S(62.f);
    static ImVec2 pos(-1.f,-1.f);
    static ImVec2 dragStart;
    static bool dragging=false;
    static bool longPressArmed=false;
    static double pressStart=0.0;
    static bool moved=false;
    if(pos.x < 0 || pos.y < 0) pos=ImVec2(std::max(S(8.f),display.x-diameter-S(18.f)), display.y*.68f);
    pos.x=Clamp(pos.x,0.f,std::max(0.f,display.x-diameter));
    pos.y=Clamp(pos.y,0.f,std::max(0.f,display.y-diameter));
    ImGui::SetNextWindowPos(ImVec2(0,0),ImGuiCond_Always);
    ImGui::SetNextWindowSize(display,ImGuiCond_Always);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding,ImVec2(0,0));
    if(ImGui::Begin("##home_bar",nullptr,ImGuiWindowFlags_NoDecoration|ImGuiWindowFlags_NoMove|
                    ImGuiWindowFlags_NoSavedSettings|ImGuiWindowFlags_NoBackground|
                    ImGuiWindowFlags_NoScrollbar|ImGuiWindowFlags_NoScrollWithMouse|
                    ImGuiWindowFlags_NoBringToFrontOnFocus)) {
        ImGui::SetCursorScreenPos(pos);
        const bool clicked=ImGui::InvisibleButton("##home_access_logo",ImVec2(diameter,diameter));
        const bool active=ImGui::IsItemActive();
        const bool hovered=ImGui::IsItemHovered();
        ImGuiIO& io=ImGui::GetIO();
        if(ImGui::IsItemActivated()) { pressStart=(float)ImGui::GetTime(); dragStart=io.MousePos; longPressArmed=true; moved=false; dragging=false; }
        if(active && longPressArmed && !dragging && ((float)ImGui::GetTime()-pressStart)>=0.30) dragging=true;
        if(active && dragging) {
            const ImVec2 delta=ImVec2(io.MouseDelta.x,io.MouseDelta.y);
            if(delta.x!=0 || delta.y!=0) moved=true;
            pos.x=Clamp(pos.x+delta.x,0.f,std::max(0.f,display.x-diameter));
            pos.y=Clamp(pos.y+delta.y,0.f,std::max(0.f,display.y-diameter));
        }
        if(ImGui::IsItemDeactivated()) {
            if(longPressArmed && !dragging && !moved) { show=true; NavigationOpen=false; }
            longPressArmed=false; dragging=false;
        }
        ImDrawList* d=ImGui::GetWindowDrawList();
        const ImVec2 center(pos.x+diameter*.5f,pos.y+diameter*.5f);
        d->AddCircleFilled(center,diameter*.5f,hovered?IM_COL32(53,47,110,250):IM_COL32(20,25,45,245),64);
        d->AddCircle(center,diameter*.5f-1.f,IM_COL32(215,177,83,255),64,S(2.f));
        d->AddCircle(center,diameter*.5f-S(5.f),IM_COL32(218,170,61,220),64,S(1.f));
        const char* logoText="PH";
        ImVec2 ts=ImGui::CalcTextSize(logoText);
        d->AddText(ImVec2(center.x-ts.x*.5f,center.y-ts.y*.5f),IM_COL32(250,247,255,255),logoText);
        if(dragging) d->AddCircle(center,diameter*.5f+S(4.f),IM_COL32(255,210,94,220),64,S(1.5f));
    }
    ImGui::End(); ImGui::PopStyleVar();
}
static void Draw() {
    if(UsableDisplaySize().x<100 || UsableDisplaySize().y<140) return;
    Theme theme(menu);
    PreviewBackdrop();
    // The access button is visible only while the main UI is closed.
    // Closing the main panel makes it available again for reopening.
    if(!show) HomeBar();
#ifndef STUDIO_STANDALONE_PREVIEW
    if(!isLogin) { LoginPanel(); return; }
    if (ui_loading::IsActive()) {
        ui_loading::RenderWindow();
        return;
    }
#endif
    if (!AutoProfileLoadAttempted) {
        AutoProfileLoadAttempted = true;
        LoadActiveProfileChoice();
        // Restore the last selected BR/MP setup on launch when one exists.
        LoadProfile(SelectedProfile);
    }
    if(ImGui::IsKeyPressed(ImGuiKey_Escape)) {
        if(NavigationOpen) NavigationOpen=false;
        else show=false;
    }
    if(ImGui::IsKeyPressed(ImGuiKey_Home) && !ImGui::GetIO().WantTextInput) {
        show=true; NavigationOpen=false;
    }
    if(show) { ControlCenter(); RadialMenu(); }
}
} // namespace StudioUI
