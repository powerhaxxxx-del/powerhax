#pragma once
#include "../ImGui/imgui.h"
#include "../ImGui/imgui_internal.h"
#include "StudioFonts.h"
#include "ControlDescriptions.h"
#include <algorithm>
#include <cstdio>
#include <cstring>
#include <cmath>

namespace StudioUI {
static ImFont* BodyFont = nullptr;
static ImFont* TitleFont = nullptr;
static float Scale = 1.0f;
static float BottomInset = 0;
static ImVec2 UsableDisplaySize() {
    const ImVec2 size=ImGui::GetIO().DisplaySize;
    return ImVec2(size.x,std::max(0.f,size.y-std::max(0.f,BottomInset)));
}
static bool GridOpen = false;
static bool ExclusiveDrag = false;
static int CurrentIcon = 0;
static const char* PendingSection = nullptr;
static ImGuiID ScrollOwner = 0;
static ImVec2 ScrollStart, ScrollLast;
static bool ScrollDragging = false;
static float S(float n) { return n * Scale; }
static ImVec2 V(float x, float y) { return ImVec2(S(x), S(y)); }
static ImVec2 Add(ImVec2 a, ImVec2 b) { return ImVec2(a.x+b.x, a.y+b.y); }
static float Clamp(float v, float lo, float hi) { return std::max(lo, std::min(hi, v)); }
static ImU32 Ink() { return IM_COL32(248,250,255,255); }
static ImU32 Muted() { return IM_COL32(187,196,212,255); }
static ImU32 Accent(int alpha=255) {
    ImVec4 c=ImGui::GetStyleColorVec4(ImGuiCol_CheckMark);
    c.w=alpha/255.f;
    return ImGui::ColorConvertFloat4ToU32(c);
}
static void ResetGestures() {
    ScrollOwner=0; ScrollDragging=false; ExclusiveDrag=false;
}
static void Initialize(ImGuiIO& io) {
    ImFontConfig config;
    config.FontDataOwnedByAtlas=false;
    config.OversampleH=2; config.OversampleV=1;
    BodyFont=io.Fonts->AddFontFromMemoryTTF((void*)RegularFontData,sizeof(RegularFontData),22,&config);
    TitleFont=io.Fonts->AddFontFromMemoryTTF((void*)HeadingFontData,sizeof(HeadingFontData),30,&config);
    if(!BodyFont) BodyFont=io.Fonts->AddFontDefault();
    if(!TitleFont) TitleFont=BodyFont;
    io.FontDefault=BodyFont;
    io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;
    GridOpen=false;
    ResetGestures();
}
struct Theme {
    ImGuiStyle previous;
    explicit Theme(const float* accent) : previous(ImGui::GetStyle()) {
        const ImVec2 display=ImGui::GetIO().DisplaySize;
        const bool portrait=display.y>display.x;
        Scale=Clamp(portrait?std::min(display.x/440.f,display.y/900.f):
                    std::min(display.x/1040.f,display.y/700.f),.65f,2.5f);
        ImGuiStyle style;
        ImGui::StyleColorsDark(&style);
        style.WindowPadding=ImVec2(16,16);
        style.FramePadding=ImVec2(12,9);
        style.ItemSpacing=ImVec2(10,9);
        style.ItemInnerSpacing=ImVec2(8,6);
        style.CellPadding=ImVec2(6,6);
        style.WindowRounding=18; style.ChildRounding=14;
        style.FrameRounding=9; style.PopupRounding=12;
        style.ScrollbarSize=5; style.ScrollbarRounding=8;
        style.GrabMinSize=12; style.GrabRounding=12;
        style.WindowBorderSize=0; style.ChildBorderSize=1;
        style.WindowMenuButtonPosition=ImGuiDir_None;
        auto* c=style.Colors;
        // PowerHax-inspired dark navy + metallic gold palette.
        const ImVec4 a(.88f,.66f,.20f,1.f);
        c[ImGuiCol_Text]=ImVec4(.94f,.95f,1.f,1.f);
        c[ImGuiCol_TextDisabled]=ImVec4(.52f,.57f,.70f,1.f);
        c[ImGuiCol_WindowBg]=ImVec4(.025f,.035f,.075f,.98f);
        c[ImGuiCol_ChildBg]=ImVec4(.035f,.05f,.105f,.92f);
        c[ImGuiCol_PopupBg]=ImVec4(.035f,.045f,.095f,.99f);
        c[ImGuiCol_Border]=ImVec4(.58f,.43f,.15f,.58f);
        c[ImGuiCol_FrameBg]=ImVec4(.065f,.085f,.16f,1.f);
        c[ImGuiCol_FrameBgHovered]=ImVec4(.17f,.13f,.055f,1.f);
        c[ImGuiCol_FrameBgActive]=ImVec4(.24f,.18f,.065f,1.f);
        c[ImGuiCol_Button]=ImVec4(.075f,.09f,.18f,1.f);
        c[ImGuiCol_ButtonHovered]=ImVec4(.24f,.18f,.065f,1.f);
        c[ImGuiCol_ButtonActive]=ImVec4(.88f,.66f,.20f,.90f);
        c[ImGuiCol_Header]=ImVec4(.15f,.12f,.055f,1.f);
        c[ImGuiCol_HeaderHovered]=ImVec4(.25f,.19f,.065f,1.f);
        c[ImGuiCol_HeaderActive]=ImVec4(.88f,.66f,.20f,.75f);
        c[ImGuiCol_CheckMark]=a; c[ImGuiCol_SliderGrab]=a;
        c[ImGuiCol_SliderGrabActive]=ImVec4(1.f,.82f,.38f,1.f); c[ImGuiCol_NavHighlight]=ImVec4(1.f,.82f,.38f,1.f);
        c[ImGuiCol_TextSelectedBg]=ImVec4(a.x,a.y,a.z,.42f);
        c[ImGuiCol_ScrollbarBg]=ImVec4(.02f,.025f,.06f,.8f);
        c[ImGuiCol_ScrollbarGrab]=ImVec4(.48f,.35f,.10f,.72f);
        c[ImGuiCol_ScrollbarGrabHovered]=ImVec4(.70f,.52f,.16f,.88f);
        c[ImGuiCol_ScrollbarGrabActive]=ImVec4(.88f,.66f,.20f,1.f);
        style.ScaleAllSizes(Scale);
        ImGui::GetStyle()=style;
        ImGui::PushFont(BodyFont);
    }
    ~Theme() { ImGui::PopFont(); ImGui::GetStyle()=previous; }
};
static void Text(ImDrawList* d, ImVec2 p, float size, ImU32 color, const char* value,
                 float wrap=0, bool heading=false) {
    d->AddText(heading?TitleFont:BodyFont,S(size),p,color,value,nullptr,wrap);
}
static float TextHeight(const char* value,float size,float width,bool heading=false) {
    return (heading?TitleFont:BodyFont)->CalcTextSizeA(S(size),FLT_MAX,width,value).y;
}
// No scene readback, extra textures or offscreen framebuffer is needed for glass.
static void Glass(ImDrawList* d,ImVec2 p,ImVec2 size,float radius=26,bool active=false,bool hovered=false) {
    const ImVec2 end=Add(p,size);
    const float r=S(radius);
    d->AddRectFilled(Add(p,V(0,3)),Add(end,V(0,3)),IM_COL32(0,0,0,105),r);
    d->AddRectFilled(p,end,active?IM_COL32(43,35,103,248):IM_COL32(9,15,37,246),r);
    if(hovered) d->AddRectFilled(p,end,IM_COL32(88,70,190,34),r);
    d->AddRect(p,end,active?IM_COL32(132,116,255,245):IM_COL32(51,65,111,220),r,0,S(active?1.6f:1.f));
    if(active) d->AddRect(p,end,IM_COL32(115,98,255,75),r+S(3),0,S(3));
    d->AddLine(ImVec2(p.x+r,p.y+S(1)),ImVec2(end.x-r,p.y+S(1)),
               active?IM_COL32(192,184,255,185):IM_COL32(83,94,145,115),S(1));
}
static bool Tap(const char* id,ImVec2 size) {
    ImGui::PushStyleColor(ImGuiCol_HeaderHovered,ImVec4(0,0,0,0));
    ImGui::PushStyleColor(ImGuiCol_HeaderActive,ImVec4(0,0,0,0));
    const bool pressed=ImGui::Selectable(id,false,ImGuiSelectableFlags_DontClosePopups,size);
    ImGui::PopStyleColor(2);
    // A release after dragging a tile is a scroll, never a toggle.
    return pressed && !(ImGui::IsMouseReleased(0) &&
        ImGui::GetIO().MouseDragMaxDistanceSqr[0]>S(8)*S(8));
}
static bool Button(const char* label,ImVec2 size=ImVec2(0,0),bool primary=false) {
    if(primary) ImGui::PushStyleColor(ImGuiCol_Button,ImGui::GetStyleColorVec4(ImGuiCol_CheckMark));
    const bool clicked=ImGui::Button(label,size);
    if(primary) ImGui::PopStyleColor();
    return clicked && !(ImGui::IsMouseReleased(0) && ImGui::GetIO().MouseDragMaxDistanceSqr[0]>S(8)*S(8));
}
static void Icon(ImDrawList* d, ImVec2 p, float size, int kind, ImU32 color) {
    const float u=size/24.f;
    auto v=[&](float x,float y){return ImVec2(p.x+x*u,p.y+y*u);};
    const float line=std::max(1.f,2*u);
    if(kind==0) { // eye
        d->AddBezierCubic(v(2,12),v(7,3),v(17,3),v(22,12),color,line);
        d->AddBezierCubic(v(2,12),v(7,21),v(17,21),v(22,12),color,line);
        d->AddCircle(v(12,12),4*u,color,16,line);
    } else if(kind==1) { // movement
        d->AddCircleFilled(v(14,4),2*u,color,12);
        d->AddLine(v(13,8),v(10,14),color,line);
        d->AddLine(v(13,8),v(7,9),color,line);
        d->AddLine(v(13,8),v(18,13),color,line);
        d->AddLine(v(10,14),v(5,21),color,line);
        d->AddLine(v(10,14),v(16,16),color,line);
        d->AddLine(v(16,16),v(19,22),color,line);
    } else if(kind==2) { // crosshair
        d->AddCircle(v(12,12),7*u,color,20,line);
        d->AddCircleFilled(v(12,12),2*u,color,12);
        d->AddLine(v(12,1),v(12,6),color,line); d->AddLine(v(12,18),v(12,23),color,line);
        d->AddLine(v(1,12),v(6,12),color,line); d->AddLine(v(18,12),v(23,12),color,line);
    } else if(kind==3) { // stacked memory blocks
        for(int i=0;i<3;++i) {
            const float x=i==0?12.f:(i==1?6.f:18.f), y=i==0?3.f:12.f;
            ImVec2 points[]={v(x,y),v(x+5,y+3),v(x+5,y+9),v(x,y+12),v(x-5,y+9),v(x-5,y+3)};
            d->AddPolyline(points,6,color,ImDrawFlags_Closed,line);
            d->AddLine(v(x-5,y+3),v(x,y+6),color,line);
            d->AddLine(v(x+5,y+3),v(x,y+6),color,line);
            d->AddLine(v(x,y+6),v(x,y+12),color,line);
        }
    } else { // gear
        d->AddCircle(v(12,12),6*u,color,16,line*1.6f);
        d->AddCircle(v(12,12),2*u,color,12,line);
        for(int i=0;i<8;++i) {
            const float a=i*3.14159265f/4;
            d->AddLine(v(12+7*cosf(a),12+7*sinf(a)),v(12+10*cosf(a),12+10*sinf(a)),color,line*1.8f);
        }
    }
}
static void EndGrid() {
    if(GridOpen) { ImGui::EndTable(); GridOpen=false; }
}
static void NextCell(bool fullWidth=false) {
    if(!GridOpen) {
        const int columns=!fullWidth && ImGui::GetContentRegionAvail().x>=S(570)?2:1;
        GridOpen=ImGui::BeginTable("##glass_grid",columns,ImGuiTableFlags_SizingStretchSame);
    }
    if(GridOpen) ImGui::TableNextColumn();
}
static void Section(const char* title) {
    EndGrid();
    ImGui::PushID(title);
    const ImVec2 p=ImGui::GetCursorScreenPos();
    Text(ImGui::GetWindowDrawList(),Add(p,V(6,12)),12,Muted(),title);
    ImGui::Dummy(V(1,38));
    if(PendingSection && std::strcmp(PendingSection,title)==0) {
        ImGui::SetScrollHereY(0); PendingSection=nullptr;
    }
    ImGui::PopID();
}
static bool Toggle(const char* label,bool* value) {
    const bool master=std::strcmp(label,"Enable ESP")==0 || std::strcmp(label,"Aimlock")==0;
    if(master) EndGrid();
    NextCell(master); ImGui::PushID(label);
    const ImVec2 p=ImGui::GetCursorScreenPos();
    const float width=ImGui::GetContentRegionAvail().x;
    const float textWidth=width-S(master?148:30);
    const float labelHeight=TextHeight(label,17,textWidth,true);
    const float descriptionHeight=TextHeight(Description(label),13,textWidth);
    const float height=std::max(S(master?90:120),S(master?36:64)+labelHeight+descriptionHeight);
    const bool pressed=Tap("##toggle",ImVec2(width,height));
    if(pressed) *value=!*value;
    auto* d=ImGui::GetWindowDrawList();
    Glass(d,p,ImVec2(width,height),26,*value,ImGui::IsItemHovered());
    if(ImGui::IsItemFocused()) d->AddRect(p,Add(p,ImVec2(width,height)),Ink(),S(26),0,S(2));
    d->AddCircleFilled(Add(p,V(30,29)),S(17),*value?Accent():IM_COL32(215,225,241,33),28);
    Icon(d,Add(p,V(19,18)),S(22),CurrentIcon,Ink());
    const ImVec2 track(p.x+width-S(60),p.y+S(17));
    const ImGuiID animation=ImGui::GetID("##knob");
    auto* storage=ImGui::GetStateStorage();
    float t=storage->GetFloat(animation,*value?1.f:0.f);
    t += ((*value?1.f:0.f)-t)*std::min(1.f,ImGui::GetIO().DeltaTime*18.f);
    storage->SetFloat(animation,t);
    d->AddRectFilled(track,Add(track,V(44,25)),*value?Accent():IM_COL32(255,255,255,44),S(13));
    d->AddCircleFilled(Add(track,V(12.5f+19*t,12.5f)),S(10),Ink(),24);
    Text(d,Add(p,V(master?63:15,master?18:52)),17,Ink(),label,textWidth,true);
    Text(d,ImVec2(p.x+S(master?63:15),p.y+S(master?24:57)+labelHeight),13,Muted(),Description(label),textWidth);
    ImGui::PopID();
    if(master) EndGrid();
    return pressed;
}
static void Sun(ImDrawList* d,ImVec2 center,float radius,ImU32 color) {
    d->AddCircleFilled(center,radius*.42f,color,24);
    for(int i=0;i<8;++i) {
        const float a=i*3.14159265f/4;
        d->AddLine(ImVec2(center.x+std::cos(a)*radius*.69f,center.y+std::sin(a)*radius*.69f),
                   ImVec2(center.x+std::cos(a)*radius,center.y+std::sin(a)*radius),color,S(2));
    }
}
static bool Slider(const char* label,float* value,float low,float high,const char* format="%.1f") {
    NextCell(); ImGui::PushID(label);
    const ImVec2 p=ImGui::GetCursorScreenPos();
    const float width=ImGui::GetContentRegionAvail().x;
    const float textWidth=std::max(S(40),width-S(28));
    const float labelHeight=TextHeight(label,17,textWidth,true);
    const float descHeight=TextHeight(Description(label),13,textWidth);
    const float height=std::max(S(116),S(78)+labelHeight+descHeight);
    auto* d=ImGui::GetWindowDrawList();
    Glass(d,p,ImVec2(width,height),28);
    Text(d,Add(p,V(16,12)),17,Ink(),label,textWidth,true);
    if(Description(label)[0]) Text(d,Add(p,V(16,34)),12,Muted(),Description(label),textWidth);

    const float left=p.x+S(24), right=p.x+width-S(24);
    const float trackY=p.y+height-S(27);
    const float trackW=std::max(1.f,right-left);
    float fraction=(high>low && std::isfinite(*value))?Clamp((*value-low)/(high-low),0.f,1.f):0.f;
    char number[64]; std::snprintf(number,sizeof(number),format,*value);
    const ImVec2 bubbleSize(S(66),S(32));
    const float knobX=left+trackW*fraction;
    ImVec2 bubble(knobX-bubbleSize.x*.5f,trackY-S(48));
    bubble.x=Clamp(bubble.x,p.x+S(8),p.x+width-bubbleSize.x-S(8));
    d->AddRectFilled(bubble,Add(bubble,bubbleSize),IM_COL32(37,39,49,255),S(12));
    d->AddText(ImGui::GetFont(),S(17),Add(bubble,V(0,4)),Ink(),number,nullptr,0.f,nullptr);

    const ImVec2 hitMin(left-S(8),trackY-S(22));
    const ImVec2 hitSize(trackW+S(16),S(44));
    ImGui::SetCursorScreenPos(hitMin);
    ImGui::InvisibleButton("##slider_hit",hitSize);
    const bool hovered=ImGui::IsItemHovered();
    const bool active=ImGui::IsItemActive();
    bool changed=false;
    if((active || (hovered && ImGui::IsMouseClicked(ImGuiMouseButton_Left))) && high>low) {
        const float mouse=Clamp((ImGui::GetIO().MousePos.x-left)/trackW,0.f,1.f);
        const float next=low+(high-low)*mouse;
        if(std::fabs(next-*value)>0.0001f) { *value=next; changed=true; }
        fraction=mouse;
    }
    ExclusiveDrag |= active;
    const float currentX=left+trackW*fraction;
    d->AddRectFilled(ImVec2(left,trackY-S(5)),ImVec2(right,trackY+S(5)),IM_COL32(224,226,233,255),S(6));
    d->AddRectFilled(ImVec2(left,trackY-S(5)),ImVec2(currentX,trackY+S(5)),IM_COL32(218,164,43,255),S(6));
    for(int i=0;i<=4;++i) {
        const float x=left+trackW*(float)i/4.f;
        d->AddCircleFilled(ImVec2(x,trackY),S(5.5f),IM_COL32(255,255,255,255),20);
    }
    d->AddCircleFilled(ImVec2(currentX,trackY),S(13),IM_COL32(218,164,43,255),28);
    d->AddCircle(ImVec2(currentX,trackY),S(15),IM_COL32(255,255,255,255),28,S(2.5f));
    ImGui::SetCursorScreenPos(p); ImGui::Dummy(ImVec2(width,height));
    ImGui::PopID(); return changed;
}

template<class Enum> static void Choice(const char* label,Enum& value,const char* const* items,int count) {
    NextCell(); ImGui::PushID(label);
    const ImVec2 p=ImGui::GetCursorScreenPos();
    const float width=ImGui::GetContentRegionAvail().x;
    const float descriptionHeight=TextHeight(Description(label),13,width-S(30));
    const float height=S(96)+descriptionHeight;
    Glass(ImGui::GetWindowDrawList(),p,ImVec2(width,height),26);
    Text(ImGui::GetWindowDrawList(),Add(p,V(15,15)),17,Ink(),label,width-S(30),true);
    Text(ImGui::GetWindowDrawList(),Add(p,V(15,41)),13,Muted(),Description(label),width-S(30));
    ImGui::SetCursorScreenPos(ImVec2(p.x+S(15),p.y+S(49)+descriptionHeight));
    ImGui::SetNextItemWidth(width-S(30));
    int selected=static_cast<int>(value);
    if(ImGui::Combo("##value",&selected,items,count)) value=static_cast<Enum>(selected);
    ImGui::SetCursorScreenPos(p); ImGui::Dummy(ImVec2(width,height));
    ImGui::PopID();
}
static void Color(const char* label,float* value) {
    NextCell(); ImGui::PushID(label);
    const ImVec2 p=ImGui::GetCursorScreenPos();
    const float width=ImGui::GetContentRegionAvail().x;
    const float height=std::max(S(92),S(51)+TextHeight(Description(label),13,width-S(95)));
    Glass(ImGui::GetWindowDrawList(),p,ImVec2(width,height),26);
    Text(ImGui::GetWindowDrawList(),Add(p,V(15,18)),16,Ink(),label,width-S(95),true);
    Text(ImGui::GetWindowDrawList(),Add(p,V(15,44)),13,Muted(),Description(label),width-S(95));
    ImGui::SetCursorScreenPos(ImVec2(p.x+width-S(62),p.y+S(21)));
    float rgb[3]={0,0,0};
    if(value) {
        const bool byteRange=value[0]>1 || value[1]>1 || value[2]>1;
        for(int i=0;i<3;++i) rgb[i]=Clamp(value[i]/(byteRange?255.f:1.f),0,1);
    }
    ImGui::BeginDisabled(value==nullptr);
    ImGui::PushStyleVar(ImGuiStyleVar_FramePadding,V(10,10));
    if(ImGui::ColorEdit3("##value",rgb,ImGuiColorEditFlags_NoInputs|ImGuiColorEditFlags_NoLabel) && value)
        for(int i=0;i<3;++i) value[i]=rgb[i];
    ImGui::PopStyleVar(); ImGui::EndDisabled();
    ImGui::SetCursorScreenPos(p); ImGui::Dummy(ImVec2(width,height));
    ImGui::PopID();
}
static void Heading(const char* title,const char* subtitle) {
    const ImVec2 p=ImGui::GetCursorScreenPos();
    const float width=ImGui::GetContentRegionAvail().x;
    const float titleHeight=TextHeight(title,28,width,true);
    const float subHeight=TextHeight(subtitle,14,width);
    Text(ImGui::GetWindowDrawList(),p,28,Ink(),title,width,true);
    Text(ImGui::GetWindowDrawList(),ImVec2(p.x,p.y+titleHeight+S(8)),14,Muted(),subtitle,width);
    ImGui::Dummy(ImVec2(width,titleHeight+subHeight+S(18)));
}
// Run after widgets, so a pill slider or popup can claim its own gesture.
static void ContentScroll() {
    auto* window=ImGui::GetCurrentWindow();
    auto& io=ImGui::GetIO();
    if(ImGui::IsMouseClicked(0) && ImGui::IsWindowHovered(ImGuiHoveredFlags_AllowWhenBlockedByActiveItem) && !ExclusiveDrag) {
        ScrollOwner=window->ID; ScrollStart=ScrollLast=io.MousePos; ScrollDragging=false;
    }
    if(ScrollOwner==window->ID) {
        if(ExclusiveDrag || GImGui->ActiveId==ImGui::GetWindowScrollbarID(window,ImGuiAxis_Y)) {
            ScrollOwner=0; ScrollDragging=false;
        } else if(ImGui::IsMouseDown(0)) {
            if(std::fabs(io.MousePos.y-ScrollStart.y)>S(8)) ScrollDragging=true;
            if(ScrollDragging) {
                ImGui::ClearActiveID();
                const float scroll=window->ScrollTarget.y<FLT_MAX?window->ScrollTarget.y:window->Scroll.y;
                ImGui::SetScrollY(window,Clamp(scroll+ScrollLast.y-io.MousePos.y,0,window->ScrollMax.y));
            }
            ScrollLast=io.MousePos;
        } else { ScrollOwner=0; ScrollDragging=false; }
    }
}
} // namespace StudioUI
