#pragma once

#include "Call_ImGui.h"

#include <algorithm>
#include <cfloat>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <string>
#include <vector>


namespace ui_loading {

// Keep this header independent from ApplicationUI.h theme namespaces.
// Gold accent matches the current PowerHax UI.
inline ImVec4 LoadingAccentColor() { return ImVec4(0.94f, 0.68f, 0.16f, 1.0f); }

struct TechNode {
    ImVec2 pos;
    float angle;
    float speed;
    float pulse;
    int nodeType;
};

struct CircuitLine {
    ImVec2 start;
    ImVec2 end;
    float progress;
    float speed;
    bool active;
};

struct HexGrid {
    ImVec2 center;
    float size;
    float rotation;
    float glowIntensity;
};

static bool showLoadingAnimation = false;
static float loadingAnimationTimer = 0.0f;
static float loadingAnimationDuration = 0.0f;
static std::vector<TechNode> techNodes;
static std::vector<CircuitLine> circuitLines;
static std::vector<HexGrid> hexGrids;
static float animationTime = 0.0f;
static float rotationAngle = 0.0f;
static float pulseWave = 0.0f;
static bool seededRandom = false;

inline float EaseOutCubic(float t) {
    t = std::max(0.0f, std::min(t, 1.0f));
    const float inv = 1.0f - t;
    return 1.0f - inv * inv * inv;
}

inline float EaseInOutSine(float t) {
    t = std::max(0.0f, std::min(t, 1.0f));
    return -(std::cos(3.14159265f * t) - 1.0f) * 0.5f;
}

inline void SeedRandomOnce() {
    if (!seededRandom) {
        std::srand((unsigned int)std::time(nullptr));
        seededRandom = true;
    }
}

inline void InitParticles(float orbitRadius) {
    SeedRandomOnce();
    techNodes.clear();
    circuitLines.clear();
    hexGrids.clear();

    const int nodeCount = 72;
    for (int i = 0; i < nodeCount; ++i) {
        TechNode node{};
        const float angle = (i / (float)nodeCount) * 2.0f * 3.14159265f;
        const float radialJitter = ((std::rand() % 100) / 100.0f - 0.5f) * orbitRadius * 0.34f;
        const float radius = orbitRadius + radialJitter;
        node.pos = ImVec2(std::cos(angle) * radius, std::sin(angle) * radius);
        node.angle = angle;
        node.speed = 0.55f + ((std::rand() % 100) / 100.0f) * 1.15f;
        node.pulse = (std::rand() % 100) / 100.0f * 6.2831853f;
        node.nodeType = std::rand() % 3;
        techNodes.push_back(node);
    }

    const int lineCount = 56;
    for (int i = 0; i < lineCount; ++i) {
        const int idxA = std::rand() % nodeCount;
        int idxB = std::rand() % nodeCount;
        if (idxA == idxB) {
            idxB = (idxB + 11) % nodeCount;
        }

        CircuitLine line{};
        line.start = techNodes[idxA].pos;
        line.end = techNodes[idxB].pos;
        line.progress = (std::rand() % 100) / 100.0f;
        line.speed = 0.45f + ((std::rand() % 100) / 100.0f) * 1.25f;
        line.active = (std::rand() % 100) < 58;
        circuitLines.push_back(line);
    }

    const int hexCount = 14;
    for (int i = 0; i < hexCount; ++i) {
        HexGrid hex{};
        const float angle = (i / (float)hexCount) * 2.0f * 3.14159265f;
        const float radius = orbitRadius * (0.48f + (i % 4) * 0.18f);
        hex.center = ImVec2(std::cos(angle) * radius, std::sin(angle) * radius);
        hex.size = orbitRadius * (0.10f + (i % 3) * 0.03f);
        hex.rotation = ((std::rand() % 360) / 180.0f) * 3.14159265f;
        hex.glowIntensity = 0.45f + ((std::rand() % 100) / 100.0f) * 0.55f;
        hexGrids.push_back(hex);
    }
}

inline void Start(float durationSeconds = 1.55f) {
    showLoadingAnimation = true;
    loadingAnimationTimer = 0.0f;
    loadingAnimationDuration = std::max(0.4f, durationSeconds);
    animationTime = 0.0f;
    rotationAngle = 0.0f;
    pulseWave = 0.0f;
    InitParticles(132.0f);
}

inline bool IsActive() {
    return showLoadingAnimation;
}

inline float GetProgress() {
    if (loadingAnimationDuration <= 0.0f) {
        return 1.0f;
    }
    return std::max(0.0f, std::min(loadingAnimationTimer / loadingAnimationDuration, 1.0f));
}

inline const char* GetStageLabel(float progress) {
    if (progress < 0.34f) {
        return "VALIDATING SSSVIP SESSION";
    }
    if (progress < 0.68f) {
        return "LOADING SSSVIP CONFIGURATION";
    }
    return "OPENING INTERFACE";
}

inline void DrawHexRing(ImDrawList* draw, const ImVec2& center, float size, float rotation, ImU32 color, float thickness) {
    for (int i = 0; i < 6; ++i) {
        const float a1 = rotation + (i / 6.0f) * 2.0f * 3.14159265f;
        const float a2 = rotation + ((i + 1) / 6.0f) * 2.0f * 3.14159265f;
        const ImVec2 p1(center.x + std::cos(a1) * size, center.y + std::sin(a1) * size);
        const ImVec2 p2(center.x + std::cos(a2) * size, center.y + std::sin(a2) * size);
        draw->AddLine(p1, p2, color, thickness);
    }
}

inline void DrawAnimation(ImDrawList* draw, const ImVec2& center, float radius, float progress) {
    const float dt = ImGui::GetIO().DeltaTime;
    animationTime += dt;
    rotationAngle += dt * 0.85f;
    pulseWave = std::sin(animationTime * 3.25f) * 0.5f + 0.5f;

    const ImVec4 accentVec = LoadingAccentColor();
    const ImU32 accent = ImGui::GetColorU32(accentVec);
    const ImU32 accentSoft = ImGui::GetColorU32(ImVec4(accentVec.x, accentVec.y, accentVec.z, 0.58f));
    const ImU32 accentGlow = ImGui::GetColorU32(ImVec4(accentVec.x * 0.92f, accentVec.y * 0.92f, accentVec.z * 0.92f, 0.22f));
    const ImU32 accentDark = ImGui::GetColorU32(ImVec4(accentVec.x * 0.26f, accentVec.y * 0.26f, accentVec.z * 0.26f, 0.82f));
    const ImU32 accentBright = ImGui::GetColorU32(ImVec4(accentVec.x * 0.82f + 0.16f, accentVec.y * 0.82f + 0.16f, accentVec.z * 0.82f + 0.16f, 0.92f));
    const ImU32 panelShade = IM_COL32(0, 0, 0, 214);

    for (int layer = 5; layer >= 0; --layer) {
        const float expand = radius * (0.92f + layer * 0.08f);
        const float alpha = 0.05f - layer * 0.0065f;
        draw->AddCircleFilled(center, expand, ImGui::GetColorU32(ImVec4(accentVec.x * 0.34f, accentVec.y * 0.34f, accentVec.z * 0.34f, ImMax(0.01f, alpha))), 64);
    }
    draw->AddCircleFilled(center, radius * 0.74f, panelShade, 48);

    for (auto& hex : hexGrids) {
        hex.rotation += dt * (0.18f + hex.glowIntensity * 0.12f);
        const float pulse = 0.72f + std::sin(animationTime * 1.9f + hex.glowIntensity * 4.5f) * 0.28f;
        const ImVec2 hexCenter(center.x + hex.center.x * 0.9f, center.y + hex.center.y * 0.9f);
        DrawHexRing(draw, hexCenter, hex.size + 6.0f, hex.rotation, ImGui::GetColorU32(ImVec4(accentVec.x * 0.42f, accentVec.y * 0.42f, accentVec.z * 0.42f, 0.12f * pulse)), 1.0f);
        DrawHexRing(draw, hexCenter, hex.size, hex.rotation, ImGui::GetColorU32(ImVec4(accentVec.x, accentVec.y, accentVec.z, 0.36f * pulse)), 1.5f);
    }

    for (auto& line : circuitLines) {
        if (line.active) {
            line.progress += dt * line.speed * 0.42f;
            if (line.progress >= 1.0f) {
                line.progress = 0.0f;
                line.active = (std::rand() % 100) < 70;
            }
        } else if ((std::rand() % 1000) < 10) {
            line.active = true;
            line.progress = 0.0f;
        }

        const ImVec2 lineStart(center.x + line.start.x, center.y + line.start.y);
        const ImVec2 lineEnd(center.x + line.end.x, center.y + line.end.y);
        draw->AddLine(lineStart, lineEnd, ImGui::GetColorU32(ImVec4(accentVec.x * 0.22f, accentVec.y * 0.22f, accentVec.z * 0.22f, 0.12f)), 1.0f);

        if (line.active && line.progress > 0.0f) {
            const ImVec2 current(
                lineStart.x + (lineEnd.x - lineStart.x) * line.progress,
                lineStart.y + (lineEnd.y - lineStart.y) * line.progress
            );
            draw->AddLine(lineStart, current, accentGlow, 1.65f);
            draw->AddCircleFilled(current, 2.2f, accentBright, 12);
        }
    }

    for (auto& node : techNodes) {
        node.angle += dt * node.speed * 0.18f;
        node.pulse += dt * (1.4f + node.speed * 0.4f);

        const float nodeRadius = radius * 0.86f + std::sin(node.pulse) * radius * 0.08f;
        node.pos.x = std::cos(node.angle) * nodeRadius;
        node.pos.y = std::sin(node.angle) * nodeRadius;

        const ImVec2 nodePos(center.x + node.pos.x, center.y + node.pos.y);
        const float pulse = 0.75f + std::sin(node.pulse) * 0.25f;

        switch (node.nodeType) {
        case 0:
            draw->AddCircleFilled(nodePos, 2.8f * pulse, accent, 10);
            draw->AddCircle(nodePos, 5.0f * pulse, accentSoft, 16, 1.15f);
            break;
        case 1:
            draw->AddRectFilled(
                ImVec2(nodePos.x - 2.4f * pulse, nodePos.y - 2.4f * pulse),
                ImVec2(nodePos.x + 2.4f * pulse, nodePos.y + 2.4f * pulse),
                ImGui::GetColorU32(ImVec4(accentVec.x * 0.72f + 0.20f, accentVec.y * 0.72f + 0.20f, accentVec.z * 0.72f + 0.20f, 0.74f))
            );
            break;
        default:
            draw->AddTriangleFilled(
                ImVec2(nodePos.x, nodePos.y - 3.4f * pulse),
                ImVec2(nodePos.x - 3.0f * pulse, nodePos.y + 2.2f * pulse),
                ImVec2(nodePos.x + 3.0f * pulse, nodePos.y + 2.2f * pulse),
                accentDark
            );
            break;
        }
    }

    const int segments = 76;
    const float mainArcLength = 0.72f;
    const float startAngle = rotationAngle;
    const float endAngle = startAngle + (2.0f * 3.14159265f * mainArcLength);

    for (int ring = 0; ring < 3; ++ring) {
        const float ringRadius = radius - ring * 16.0f;
        const float thickness = 3.1f - ring * 0.55f;
        const float alpha = 230.0f - ring * 60.0f;

        for (int i = 0; i < segments; ++i) {
            const float t0 = i / (float)segments;
            const float t1 = (i + 1) / (float)segments;
            const float a0 = startAngle + (endAngle - startAngle) * t0;
            const float a1 = startAngle + (endAngle - startAngle) * t1;
            const ImVec2 p0(center.x + std::cos(a0) * ringRadius, center.y + std::sin(a0) * ringRadius);
            const ImVec2 p1(center.x + std::cos(a1) * ringRadius, center.y + std::sin(a1) * ringRadius);
            const float fade = 0.18f + t0 * 0.82f;
            draw->AddLine(p0, p1, ImGui::GetColorU32(ImVec4(accentVec.x, accentVec.y, accentVec.z, (alpha / 255.0f) * fade)), thickness);
        }
    }

    const float progressRadius = radius + 24.0f;
    const float progressSweep = 2.0f * 3.14159265f * (0.1f + 0.9f * EaseInOutSine(progress));
    const float progressStart = -1.5707963f;
    for (int i = 0; i < 54; ++i) {
        const float t0 = i / 54.0f;
        const float t1 = (i + 1) / 54.0f;
        const float a0 = progressStart + progressSweep * t0;
        const float a1 = progressStart + progressSweep * t1;
        const ImVec2 p0(center.x + std::cos(a0) * progressRadius, center.y + std::sin(a0) * progressRadius);
        const ImVec2 p1(center.x + std::cos(a1) * progressRadius, center.y + std::sin(a1) * progressRadius);
        draw->AddLine(p0, p1, ImGui::GetColorU32(ImVec4(0.96f, 0.97f, 0.99f, 0.40f + 0.24f * t0)), 2.2f);
    }

    for (int i = 0; i < 10; ++i) {
        const float angle = rotationAngle * 0.76f + (i / 10.0f) * 2.0f * 3.14159265f;
        const float inner = radius * 0.48f;
        const float outer = radius * (0.65f + std::sin(animationTime * 1.6f + i) * 0.04f);
        const ImVec2 p0(center.x + std::cos(angle) * inner, center.y + std::sin(angle) * inner);
        const ImVec2 p1(center.x + std::cos(angle) * outer, center.y + std::sin(angle) * outer);
        draw->AddLine(p0, p1, ImGui::GetColorU32(ImVec4(accentVec.x * 0.62f, accentVec.y * 0.62f, accentVec.z * 0.62f, 0.42f)), 1.35f);
    }

    const float corePulse = 0.76f + pulseWave * 0.24f;
    draw->AddCircleFilled(center, 14.0f * corePulse, IM_COL32(0, 0, 0, 236), 20);
    draw->AddCircle(center, 18.0f * corePulse, accentSoft, 24, 2.0f);
    draw->AddCircleFilled(center, 6.5f * corePulse, accentBright, 20);
}

inline bool RenderWindow(ImTextureID backgroundTexture = nullptr) {
    if (!showLoadingAnimation) return false;
    IM_UNUSED(backgroundTexture);

    ImGuiIO& io = ImGui::GetIO();
    const ImVec2 display = io.DisplaySize;
    if (display.x <= 1.0f || display.y <= 1.0f) return false;

    const float dt = (io.DeltaTime > 0.0f && io.DeltaTime < 0.25f) ? io.DeltaTime : (1.0f / 60.0f);
    loadingAnimationTimer += dt;
    animationTime += dt;
    rotationAngle += dt * 1.1f;
    pulseWave = 0.5f + 0.5f * std::sin(animationTime * 3.2f);
    const float progress = GetProgress();

    // Full-screen overlay: avoids small-screen clipping and old ImGui viewport API differences.
    ImGui::SetNextWindowPos(ImVec2(0.0f, 0.0f), ImGuiCond_Always);
    ImGui::SetNextWindowSize(display, ImGuiCond_Always);
    ImGui::SetNextWindowBgAlpha(1.0f);
    const ImGuiWindowFlags flags = ImGuiWindowFlags_NoDecoration |
        ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoResize |
        ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoScrollbar |
        ImGuiWindowFlags_NoInputs | ImGuiWindowFlags_NoBringToFrontOnFocus;

    if (ImGui::Begin("##powerhax_loading_overlay", nullptr, flags)) {
        ImDrawList* draw = ImGui::GetWindowDrawList();
        const ImVec2 center(display.x * 0.5f, display.y * 0.43f);
        const float minDim = std::min(display.x, display.y);
        const float radius = std::max(38.0f, std::min(100.0f, minDim * 0.16f));
        const ImVec4 accent = LoadingAccentColor();
        const ImU32 gold = ImGui::GetColorU32(accent);
        const ImU32 goldSoft = ImGui::GetColorU32(ImVec4(accent.x, accent.y, accent.z, 0.38f));
        const ImU32 white = IM_COL32(246, 246, 252, 255);
        const ImU32 muted = IM_COL32(170, 174, 190, 255);

        draw->AddRectFilled(ImVec2(0, 0), display, IM_COL32(4, 6, 17, 250));
        // Soft gold radial glow and rotating rings.
        for (int i = 5; i >= 0; --i) {
            const float r = radius * (0.55f + i * 0.13f);
            const int alpha = 5 + (5 - i) * 2;
            draw->AddCircleFilled(center, r, IM_COL32(218, 170, 61, alpha), 40);
        }
        draw->AddCircle(center, radius * 1.18f, IM_COL32(218, 170, 61, 90), 48, 1.5f);
        draw->AddCircle(center, radius * 0.98f, goldSoft, 48, 2.0f);
        for (int ring = 0; ring < 3; ++ring) {
            const float rr = radius * (0.83f - ring * 0.19f);
            const float start = rotationAngle * (ring % 2 ? -1.0f : 1.0f) + ring * 1.7f;
            const float sweep = 4.35f - ring * 0.65f;
            ImVec2 prev(center.x + std::cos(start) * rr, center.y + std::sin(start) * rr);
            const int segments = 24;
            for (int j = 1; j <= segments; ++j) {
                const float a = start + sweep * (j / (float)segments);
                ImVec2 cur(center.x + std::cos(a) * rr, center.y + std::sin(a) * rr);
                draw->AddLine(prev, cur, ring == 0 ? gold : goldSoft, ring == 0 ? 3.0f : 1.8f);
                prev = cur;
            }
        }
        for (int i = 0; i < 16; ++i) {
            const float a = rotationAngle * 0.7f + i * (6.2831853f / 16.0f);
            const float rr = radius * (1.03f + 0.08f * std::sin(animationTime * 2.0f + i));
            const ImVec2 pt(center.x + std::cos(a) * rr, center.y + std::sin(a) * rr);
            draw->AddCircleFilled(pt, (i % 3 == 0) ? 2.5f : 1.4f, (i % 3 == 0) ? gold : goldSoft, 8);
        }
        draw->AddCircleFilled(center, radius * 0.43f, IM_COL32(8, 12, 26, 245), 48);
        draw->AddCircle(center, radius * 0.43f, gold, 48, 2.0f);

        const char* brand = "POWERHAX SSSVIP";
        const char* title = "LOGIN SUCCESSFUL";
        const char* stage = progress < 0.34f ? "RESTORING SESSION" : (progress < 0.68f ? "LOADING SETTINGS" : "OPENING INTERFACE");
        const ImVec2 brandSize = ImGui::CalcTextSize(brand);
        const ImVec2 titleSize = ImGui::CalcTextSize(title);
        const ImVec2 stageSize = ImGui::CalcTextSize(stage);
        draw->AddText(ImVec2((display.x - brandSize.x) * 0.5f, center.y + radius * 1.28f), gold, brand);
        draw->AddText(ImVec2((display.x - titleSize.x) * 0.5f, center.y + radius * 1.28f + 28.0f), white, title);
        draw->AddText(ImVec2((display.x - stageSize.x) * 0.5f, center.y + radius * 1.28f + 55.0f), muted, stage);

        const float barW = std::min(display.x * 0.72f, 360.0f);
        const ImVec2 barMin((display.x - barW) * 0.5f, center.y + radius * 1.28f + 88.0f);
        const ImVec2 barMax(barMin.x + barW, barMin.y + 8.0f);
        draw->AddRectFilled(barMin, barMax, IM_COL32(36, 39, 54, 255), 4.0f);
        draw->AddRectFilled(barMin, ImVec2(barMin.x + barW * progress, barMax.y), gold, 4.0f);
        char pct[16];
        std::snprintf(pct, sizeof(pct), "%d%%", (int)std::lround(progress * 100.0f));
        const ImVec2 pctSize = ImGui::CalcTextSize(pct);
        draw->AddText(ImVec2((display.x - pctSize.x) * 0.5f, barMax.y + 12.0f), white, pct);
    }
    ImGui::End();

    if (loadingAnimationTimer >= loadingAnimationDuration) {
        showLoadingAnimation = false;
        loadingAnimationTimer = 0.0f;
        return true;
    }
    return false;
}

} // namespace ui_loading
