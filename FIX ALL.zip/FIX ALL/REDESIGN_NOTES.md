# PowerHax UI update notes

## Changes applied in this pass
- Replaced the bottom line-bar access affordance with a circular `PH` access button in `src/main/jni/UI/ApplicationUI.h`.
- Added a 0.3-second hold before drag begins, smooth pointer-delta movement, and display-boundary clamping. The position currently persists for the running UI session only.
- Removed the HomeBar tooltip popup.
- Added Save All Settings / Load All Settings controls to the Settings page, wired to the existing `saveAllConfig()` / `loadAllConfig()` functions.
- Added a subtle full-width animated wave accent over the license input field. It is decorative and does not reveal or alter the key.
- Kept the existing live ImGui FPS/frame-time reading.
- Did not modify `Blueprint.h` or its declarations, per request.

## Important limitations / not yet verified
- The circular button currently displays `PH` text; the actual client logo asset has not been embedded in this pass. Replace it only after providing the desired logo asset in this source ZIP.
- Button position is not persisted across process restarts yet.
- Existing `saved.h` writes `/storage/emulated/0/Download/wc_config.dat`; this path can fail under scoped storage. The new UI buttons expose the existing functions, but storage migration to app-private files and complete serialization of every visible UI-only preference still need implementation.
- Theme preset profiles and persistent profile slots are not fully integrated in this pass.
- FPS is ImGui/UI rendering FPS, not guaranteed game-engine FPS.
- Full Android/NDK build and on-device crash testing were not available here. ZIP integrity and static source checks only.

## Frame pacing and loading animation update
- Left the existing 120 FPS / 180 FPS UI buttons and their behavior unchanged.
- Removed a detached anti-overheat sleep worker that did not control the render cadence.
- Reduced loading-animation draw calls (rings/glow particles) to lower overlay GPU/CPU cost while retaining its existing window sizing.
- Set the post-login loading animation duration to 8 seconds.
- A stable 120 FPS cannot be guaranteed by this source alone; actual frame rate depends on the game's frame pacing, Android refresh-rate mode, GPU/CPU thermal state, and device support. No full NDK build was run here.
